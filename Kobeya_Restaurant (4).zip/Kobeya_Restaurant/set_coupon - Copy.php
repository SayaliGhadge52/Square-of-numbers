<?php

include 'includes/_dbconnect.php';
include 'includes/function.php';

$coupon_code = get_safe_value($_POST['coupon_code']);
$totalPrice = get_safe_value($_GET['totalPrice']);
$res=mysqli_query($conn,"select * from coupon_code where coupon_code='$coupon_code'");
$count = mysqli_num_rows($res);
if($count>0){
	$row=mysqli_fetch_assoc($res);
	$cart_min_value=$row['cart_min_value'];
	$coupon_type=$row['coupon_type'];
	$coupon_value=$row['coupon_value'];
	$coupon_code=$row['coupon_code'];
	$expired_on=strtotime($row['expired_on']);
		
	$discount_value= ($totalPrice / 100) * $coupon_code;

    $final_price = $totalPrice - $discount_value;

    echo $final_price;

	
	$arr=array('status'=>'success','msg'=>'Coupon Code applied');
	

} else{
	$arr=array('status'=>'error','msg'=>'Please enter valid Coupon code!!');	
}
echo json_encode($arr);
?>






