<div class="container-fluid" style="margin-top:98px; margin-left:160px;">
    <div class="col-lg-12">
	     		<div class="col-sm-2 text-center" style="color:#FFFFFF; background-color:#426047; margin-left:300px;" >
                    <h2><b>Wishlist</b></h2>
                  </div>		
        <div class="row">
                  
            <!-- Table Panel -->
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                    <table class="table table-bordered table-hover mb-0">
                        <thead style="color:#FFFFFF; background-color:#426047;">
                        <tr>
                                <th>Sr.No.</th>
								<th>User Id</th>
								<th>Product Id</th>
                                <th class="text-left" scope="col">Product Name</th>
                                <th class="text-center" style="width:10%;">Price</th>
                                <th class="text-center" scope="col">Created At</th>
								
                        </tr>
                        </thead>
                        <tbody>
                          <?php   
								
								
                                $sql = "SELECT * FROM wishlist JOIN product on product.productId=wishlist.product_id";
                                $result = mysqli_query($conn, $sql);
                        
								if(mysqli_num_rows($result)>0){
									
			
                                while($row = mysqli_fetch_assoc($result)){
                            ?>
								<tr>
								<td class="text-center"><b><?php echo $row["id"]; ?></b></td>
								<td class="text-center"><b><?php echo $row["userId"]; ?></b></td>
								<td class="text-center"><b><?php echo $row["productId"]; ?></b></td>
								<td class="text-left"><b><?php echo $row["productName"]; ?></b></td>
								<td class="text-center"><b><?php echo $row["productPrice"]; ?></b></td>
								<td class="text-center"><b><?php echo $row["added_on"]; ?></b></td>
							 
							
								</tr>
                             <?php
				             }
			                 } else {
				             echo "0 results";
			                 }
			                 ?> 
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
    </div>	    
</div>



