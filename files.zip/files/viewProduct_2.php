<!doctype html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title id=title>Kobeya</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-blue-grey.css">
    <style>
	body {
    font-family: "open_sansregular" !important;
}
	
    #cont {
        min-height : 578px;
    }
	
	.table-bordered td, .table-bordered th {
    border:none !important;
 solid #d87944 !important;

	}
	
	
	input[type=number] {
  width:50px !important;
  
  
	}
	 .customRadio input[type="radio"] {
     position: absolute;
     left: -9999px
 }

 .customRadio input[type="radio"]+label {
     position: relative;
     padding: 3px 0 0 40px;
	 margin-left: 21px;
     cursor: pointer
 }

 .customRadio input[type="radio"]+label:before {
     content: '';
     background: #fff;
     border: 2px solid #311B92;
     height: 25px;
     width: 25px;
     border-radius: 50%;
     position: absolute;
     top: 0;
     left: 0
 }

 .customRadio input[type="radio"]+label:after {
     content: '';
     background: #311B92;
     width: 15px;
     height: 15px;
     border-radius: 50%;
     position: absolute;
     top: 5px;
     left: 5px;
     opacity: 0;
     transform: scale(2);
     transition: transform 0.3s linear, opacity 0.3s linear
 }

 .customRadio input[type="radio"]:checked+label:after {
     opacity: 1;
     transform: scale(1)
 }

 .customCheckbox input[type="checkbox"] {
     position: absolute;
     left: -9999px
 }

 .customCheckbox input[type="checkbox"]+label {
     position: relative;
     padding: 3px 0 0 40px;
     cursor: pointer;
     color: rgb(120, 119, 121)
 }

 .customCheckbox input[type="checkbox"]+label:before {
     content: '';
     background: #fff;
     border: 2px solid #ccc;
     border-radius: 3px;
     height: 25px;
     width: 25px;
     position: absolute;
     top: 0;
     left: 0
 }

 .customCheckbox input[type="checkbox"]+label:after {
     content: '';
     border-style: solid;
     border-width: 0 0 2px 2px;
     border-color: transparent transparent #311B92 #311B92;
     width: 15px;
     height: 8px;
     position: absolute;
     top: 6px;
     left: 5px;
     opacity: 0;
     transform: scale(2) rotate(-45deg);
     transition: transform 0.3s linear, opacity 0.3s linear
 }

 .customCheckbox input[type="checkbox"]:checked+label:after {
     opacity: 1;
     transform: scale(1) rotate(-45deg);
     color: #311B92
 }
	 .box-shadow--16dp {
     box-shadow: 0 16px 24px 2px rgba(0, 0, 0, .14), 0 6px 30px 5px rgba(0, 0, 0, .12), 0 8px 10px -5px rgba(0, 0, 0, .2)
 }
 
 .my_checkbox {
     margin-left: 3%;
	 margin-bottom: 18px;
 }

 .model-content {
     width: 1000px;
     width: 100% !important
 }

.card-body .wishlist{
	float: right;
    }

    </style>
	
	
</head>
<body>
    <?php include 'includes/_dbconnect.php';?>
    <?php require 'includes/_nav.php' ?>
<div class="w3-container w3-content" style="max-width:1100px; z-index:1;">

        <div class="row jumbotron" style="background-color:#ffff" !important;>
        <?php
            $productId = $_GET['productid'];
            $sql = "SELECT * FROM `product` WHERE productId = $productId";
            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
            $productName = $row['productName'];
            $productPrice = $row['productPrice'];
            $productDesc = $row['productDesc'];
            $productCategorieId = $row['productCategorieId'];
			
        ?>
         <script> document.getElementById("title").innerHTML = "<?php echo $productName; ?>"; </script>
		 
        <?php
        echo  '<div class="col-md-4">
                <img src="img/menu-'.$productId. '.jpg" width="300px" height="300px">
            </div>
            <div class="col-md-8 my-4">
                <h3>' . $productName . '</h3>
                <h5 style="color: #333"><b>AED '.$productPrice. '</b></h5>
                <p class="mb-0">' .$productDesc .'</p>';
				
				 $quaSql1 = "SELECT `choice_name`,`choice_price` FROM `add_ons` WHERE productId = '$productId'";
				$query = "SELECT `icon_image` FROM `nutriicons` WHERE productId = '$productId'";
				$quaresult1 = mysqli_query($conn, $quaSql1);
                $queryresult = mysqli_query($conn,$query);
				while($queryrow=mysqli_fetch_array($queryresult)){
					
					$nutriimage=$queryrow['icon_image'];
					
					
					 echo  '<div class="col-md-4" style="display:inline !important;">
               
				<img src="./admin/includes/upload/'.$queryrow['icon_image']. '" width="48px" height="48px" >
				
				
				

            </div>';
					
					
					}
				
					echo '<H3>Add Ons</H3>';
					
								while($quaExistRows2=mysqli_fetch_array($quaresult1)){
								$choice_name=$quaExistRows2['choice_name'];
								$choice_price=$quaExistRows2['choice_price'];
							
							
					
									
/*echo     '<div class="table-responsive">  
                               <table class="table table-bordered">  
                                    <tr>  
                                         <td width="50%">'.$choice_name.'</td>
										<td></td>
                                         <td width="50%">AED ' .$choice_price.'</td>  
										  <td width="50%">
										  
										  <input type="checkbox" name="choices[]" value="checked" style="text-align:center; vertical-align: middle;"></td>  
                                    </tr>  
                               </table>  
                                
                          </div> '; */

									
								}
							
			
                if($loggedin){
                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE productId = '$productId' AND `userId`='$userId'";
					 //$quaSql1 = "SELECT `choice_name`,`choice_price` FROM `add_ons` WHERE productId = '$productId'";
					 //$query = "SELECT `icon_image` FROM `nutriicons` WHERE productId = '$productId'";
					
					
                    $quaresult = mysqli_query($conn, $quaSql);
                    $quaExistRows = mysqli_num_rows($quaresult);
					  // $quaresult1 = mysqli_query($conn, $quaSql1);
					 //$queryresult = mysqli_query($conn,$query);
			
					
					
								while($quaExistRows1=mysqli_fetch_array($quaresult)){
									$Quantity=$quaExistRows1['itemQuantity'];
																	
	
									echo '<form id="frm' . $productId . '">
                                                    <input type="hidden" name="productId" value="' . $productId . '">
													
													
                                                    <input type="number" name="quantity" value="' . $Quantity . '" class="text-center" onchange="updateCart(' . $productId . ')" onkeyup="return false" style="position:absolute;border-color:#d87944 !important; min=1 oninput="check(this)" onClick="this.select();">
                                                </form>
												';
									}
                                    if($quaExistRows == 0) {
                                        echo '
										
										<form action="includes/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$productId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>
											  <span class="wishlist"><a href="wishlist.php?id=' .$productId. '" class="btn btn-primary my-2" style="background-color:#426047 !important;border-color:#426047 !important;"><i class="fa fa-heart"></i></a></span>';
                                    }else {
                                        echo '<a href="viewCart.php"><button class="btn btn-primary mx-2" style="background-color:transparent !important;border:none !important;"><i class="fas fa-shopping-cart" style="margin-left:41px;font-size:30px;color:#d87944";></i> 
<span style="color:#426047!important;position:relative;height:24px;width:24px;top:-25px; right:10px;font-weight:bold;"> '.$Quantity.'</span></button></a>' ;

   echo '<button type="button" style="background-color:#426047 !important"; class="btn btn-primary" data-toggle="modal" data-target="#myModal" id="Modal_button">Add to '. $productName .' </button> 



	<a href="wishlist.php?id=' .$productId. '" class="btn btn-primary my-2" style="background-color:#426047 !important;border-color:#426047 !important; z-index:1;"><i class="fa fa-heart"></i></a>
               <h6 class="my-1"> View </h6>
                <div class="mx-4">
                    <a href="viewProductList.php?catid=' . $productCategorieId . '" class="active text-dark">
                    <i class="fas fa-qrcode"></i>
                        <span>All Product</span>
                    </a>
                </div>
                <div class="mx-4">
                    <a href="index.php" class="active text-dark">
                    <i class="fas fa-qrcode"></i>
                        <span>All Category</span>
                    </a>
                </div>

<div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header"> <button type="button" class="close" data-dismiss="modal">&times;</button> </div> <!-- Modal body -->
                <div class="modal-body mb-0 pb-0 mt-0">
                    <div class="container ">
                        <!-- custom radio button -->
                        <div class="holder">
                            <div class="row mb-1">
                                <div class="col">
                                    <h2>Main</h2>
									<p>Required</p>
                                </div>
                            </div>
                            <form action="#" class="customRadio customCheckbox m-0 p-0">
                                <div class="row mb-0">
                                    <div class="row justify-content-start">
                                        <div class="col-12">
                                            <div class="row"> <input type="radio" name="textEditor" id="dreamweaver" checked> <label for="dreamweaver">Chicken Skewers</label> </div>
                                            <div class="row"> <input type="radio" name="textEditor" id="sublime"> <label for="sublime">Chicken Fries</label> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-0 ml-4">
								  <div class="row"> <label for="dreamweaver">Choice of Free Sauce</label> </div>
                                    <div class="col-12 my_checkbox ">
                                        <div class="row"> <input type="checkbox" id="screenshots" checked> <label for="javascript" id="screenshots_label">BBQ-Sauce</label> </div>
                                        <div class="row"> <input type="checkbox" id="RAW"> <label for="RAW">Chili Sauce</label> </div>
                                        <div class="row"> <input type="checkbox" id="Library"> <label for="Library">Spicy Ketch Up</label> </div>
                                    </div>
                                </div>';
                              
							echo  '<H3>Add Ons</H3>';
						
							
							
							$quaSql1 = "SELECT `choice_name`,`choice_price` FROM `add_ons` WHERE productId = '$productId'";
							
								$quaresult1 = mysqli_query($conn, $quaSql1);
							
							while($quaExistRows2=mysqli_fetch_array($quaresult1)){
								$choice_name=$quaExistRows2['choice_name'];
								$choice_price=$quaExistRows2['choice_price'];
							
							
							echo '<div class="table-responsive">  
                               <table class="table table-bordered">  
                                    <tr>  
                                         
										 <td> <input type="checkbox" value="'.$choice_name.'" onClick="this.checked=!this.checked;"><label> '.$choice_name.'</label></td>
                                      <td><p> '.$choice_price.'</p></td>
										 
                                    </tr>  
                               </table>  
                                
                          </div> '; 

									
								}
							
							
								
					
							  
                          '</form>
						  
                        </div>
                    </div>
                </div> 
				';
	
                                    }
                                }
						
                else{
                    echo '
					
					<button class="btn btn-primary my-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>
					
					';
					
					
                }

                echo '</form>
				
				

            </div>
			'; 
				
        ?>
        </div>
    </div>
</div>
</div>

   <!-- ============================================== Related PRODUCTS Start============================================== -->
<div class="container my-4" id="cont">
<h2 style="border-bottom: 2px solid #e3e3e3;"><strong>Related Product</strong></h2>
<div class="row">
 <?php 
        //$sql_related = "SELECT * FROM `product` where productId != $productId order by rand() limit 4 ";  
		$sql_related = "SELECT * FROM product where productId != '$productId' and productCategorieId='$productCategorieId' limit 4 ";
        $result = mysqli_query($conn, $sql_related);
        while($row = mysqli_fetch_assoc($result)){
          $id = $row['productId'];
          $cat = $row['productName'];
          $desc = $row['productDesc'];
		  $productPrice = $row['productPrice'];
          echo '<div class="col-xs-3 col-sm-3 col-md-3">
                  <div class="card" style="width: 18rem;">
                    <img src="img/menu-'.$id. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                    <div class="card-body">
                      <h5 class="card-title"><a style="color:#d87944 !important;" href="viewProductList.php?catid=' . $id . '">' . substr($cat, 0, 15). '...</a></h5>
                      <p class="card-text">' . substr($desc, 0, 20). '... </p>
                      <h5 style="color: #333"><b>AED '.$productPrice.'.00</b><span class="wishlist"><a href="wishlist.php?id=' .$id. '"><i class=" fa fa-heart" style="color: grey"></i></a></span></h5>
					  <button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>
					  <a href="viewProduct.php?productid=' . $id . '" class="mx-2"><button class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">Quick View</button></a>
                    </div>
                  </div>
                </div>';
        }
        ?>
</div>
</div>
</div>
   <!-- ============================================== Related PRODUCTS Start============================================== -->
   
<script>
        function check(input) {
            if (input.value <= 0) {
                input.value = 1;
            }
        }
        function updateCart(id) {
            $.ajax({
                url: 'includes/_manageCart.php',
                type: 'POST',
                data:$("#frm"+id).serialize(),
                success:function(res) {
                    location.reload();
                } 
            })
        }
    </script>
	<script>
	
	</script>
	
	
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>