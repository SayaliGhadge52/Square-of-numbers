<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


	<link rel="stylesheet" href="assets/css/swiper.min.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.css" />
<link rel="stylesheet" href="assets/css/addstyle.css?v=2-10102020">
<link rel="stylesheet" href="assets/css/addstyle2.css?v=2-10102020-1" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Home</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	
	
	<?php include 'includes/_dbconnect.php';?>
  <?php require 'includes/_nav.php' ?>
	
	<style>
       body{
		   
		   font-size: 19px !important;
	   }

        #locator-input-section {
            width: 100%;
        
            max-width: 800px;
           margin: 25px 1px;
        }
		.element {
    background:rgb(134, 226, 255);
    min-width:700px;
    margin:10px;
}
p {
    display:inline-block;
    width:70%;
    background:white;
    vertical-align:middle;
}
img {
    display:inline-block;
    vertical-align:middle;
    padding-right:5%;
}
		
	.services-sec .service {
    overflow: hidden;
    background: #22262F;
    -webkit-border-radius: 10px;
    -ms-border-radius: 10px;
    border-radius: 10px;
    padding: 44px 45px 41px;
    position: relative;
}	

.services-sec .service > span {
    display: inline-block;
    color: #D8AB37;
    font-size: 14px;
    margin-bottom: 12px;
    font-weight: 500;
}
.services-sec .service p {
    font-size: 16px;
    line-height: 27px;
    color: rgba(255, 255, 255, 0.7);

}

.services-sec .service > h4 {
    color: #fff;
    font-size: 20px;
    margin-bottom: 25px;
    </style>
	

	
	<style>
	body {
    font-family: "open_sansregular" !important;
}
	


.showcase-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  font-size: 1.6rem;
}

.main-title {
  text-transform: uppercase;
  margin-top: 1.5em;
}
	
	
	
	
	/* Home Banner */

.eateasy-home-banner{
    background: url('img/kobeya-banner.jpg');
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    min-height: 300px;
    width: 100%;
    margin-top: -20px;
}

/* Location Search  */
.eateasy-location-search{
    padding-bottom: 15px;
}
.eateasy-location-search .location-search-box-outer{
    min-height: 300px;
    border-radius: 10px;
    background: #ffffff;
    -webkit-box-shadow: 0px 3px 6px 0px rgba(0,0,0,0.16);
    -moz-box-shadow: 0px 3px 6px 0px rgba(0,0,0,0.16);
    box-shadow: 0px 3px 6px 0px rgba(0,0,0,0.16);
    margin-top: -100px;
    display: grid;

}

.eateasy-location-search .location-search-box-outer .main-category-box{
    margin: 0px;
    padding: 0px;
    display: flex;
    list-style: none;
    border-bottom: solid 1px hsla(0, 0%, 0%, 0.18);
}
.eateasy-location-search .location-search-box-outer .main-category-button{
    flex: 1;
    /* padding: 10px; */
    border-right: solid 1px hsla(0, 0%, 0%, 0.18);
    border-bottom: #f3f3f3 solid 5px;
    cursor: pointer;
    background: #f3f3f3;
    display: none;
}
.eateasy-location-search .location-search-box-outer .main-category-button a{
    padding: 10px;
    display: block;
}
.eateasy-location-search .location-search-box-outer .main-category-button:nth-child(1){
    border-radius: 10px 0 0 0;
}
.eateasy-location-search .location-search-box-outer .main-category-button:nth-last-child(1){
    border-radius: 0 10px 0 0;
}
.eateasy-location-search .location-search-box-outer .main-category-button:nth-child(-n+2){
    display: block;
}
.eateasy-location-search .location-search-box-outer .category-more .hidden-category:nth-child(-n+2){
    display: none;
}
.eateasy-location-search .location-search-box-outer .main-category-button:nth-last-child(1){
    display: block;
    border-radius: 0 10px 0 0;
}
.eateasy-location-search .location-search-box-outer .main-category-box .dropdown{
    display: flex;
    flex: 1;
}
.eateasy-location-search .location-search-box-outer .main-category-box .dropdown .main-category-button:nth-child(1){
    border-radius: 0 10px 0 0;
}
.eateasy-location-search .location-search-box-outer .main-category-button.active{
    border-bottom: #d87944 solid 5px;
    background: #ffffff;
}
.eateasy-location-search .location-search-box-outer .main-category-button:hover{
    border-bottom: #426047 solid 5px;
}
.eateasy-location-search .location-search-box-outer .main-category-button .category-icon{
    text-align: center;
}
.eateasy-location-search .location-search-box-outer .main-category-button .category-icon img{
    width: 60px;
    margin: 0 auto;
}
.eateasy-location-search .location-search-box-outer .main-category-button .category-name{
    text-align: center;
    font-size: 12px;
    font-weight: 600;
    font-family: Roboto, Arial, sans-serif;
    color: #4E4E4E;
    line-height: 12px;
    padding-top: 4px
}





 /* // Small devices (landscape phones, 576px and up) */
@media (min-width: 576px) { 
    .eateasy-location-search .location-search-box-outer .main-category-button:nth-child(-n+3){
        display: block;
    }
    .eateasy-location-search .location-search-box-outer .main-category-button:nth-last-child(1){
        display: block;
        border-radius: 0 10px 0 0;
    }
    .eateasy-location-search .location-search-box-outer .category-more .hidden-category:nth-child(-n+3){
        display: none;
    }
 }

/* // Medium devices (tablets, 768px and up) */
@media (min-width: 768px) { 
    .eateasy-location-search .location-search-box-outer .main-category-button:nth-child(-n+5){
        display: block;
    }
    .eateasy-location-search .location-search-box-outer .category-more .hidden-category:nth-child(-n+5){
        display: none;
    }
 }

/* // Large devices (desktops, 992px and up) */
@media (min-width: 992px) { 
    .eateasy-location-search .location-search-box-outer .main-category-button:nth-child(-n+7){
        display: block;
    }
    .eateasy-location-search .location-search-box-outer .category-more .hidden-category:nth-child(-n+7){
        display: none;
    }
 }

/* // Extra large devices (large desktops, 1200px and up) */
@media (min-width: 1200px) { 
    .eateasy-location-search .location-search-box-outer .main-category-button:nth-child(-n+8){
        display: block;
    }
    .eateasy-location-search .location-search-box-outer .category-more .hidden-category:nth-child(-n+8){
        display: none;
    }
}


/* Model view-categories */

#view-categories{
    z-index: 999999;

    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;

}
#view-categories .modal-dialog{
    z-index: 95;
    width: 600px;
    border-radius: 5px;
    left: 0;
    right: 0;
    top: 35px;
    margin: auto;
    background-color: #fff;
    position: absolute;
}
#view-categories .modal-dialog .main-category-box{
    margin: 0px;
    padding: 0;
    list-style: none;
    display: flex;
    flex-wrap: wrap;
    flex-direction: row;
}
#view-categories .modal-dialog .main-category-box a{
    width: calc(25% - 16px);
    margin: 8px;
}
#view-categories .modal-dialog .main-category-box .main-category-button{
    padding: 10px;
    text-align: center;
    border: 1px solid #ddd;
    border-radius: 3px;
    min-height: 90px;
}
#view-categories .modal-dialog .main-category-box .main-category-button .category-icon img{
    width: 40px;
}
#view-categories .modal-dialog .main-category-box .main-category-button .category-name{
    text-align: center;
    font-size: 12px;
    font-weight: 600;
    font-family: Roboto, Arial, sans-serif;
    color: #4E4E4E;
    line-height: 12px;
    padding-top: 4px;
}







.eateasy-location-search .location-search-box-outer .eateasy-main-search{
    padding-bottom: 30px;
    display: flow-root;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search h1{
    text-align: center;
    font-weight: 600;
    font-size: 26px;
    margin: 40px 0 20px 0;
}
.eateasy-location-search .location-search-box-outer .main-search-mobile.city{
    width:22%;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .search-bar{
    width: calc(59% - 16px);
    margin: 0 8px;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .search-bar .search-field{
    width: calc(100% - 3px);
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .input-group{
    width: 100%;
}

.eateasy-location-search .location-search-box-outer .eateasy-main-search .input-group .main-search-mobile.city{
    left: 0px !important;
}
.search-field{
    padding: 11px 22px;
    font-size: 16px;
    color: #555;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin: 0 3px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    -webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s

}

.eateasy-location-search .location-search-box-outer .eateasy-main-search .search-button {
    background: #e71c38;
    width: 18% !important;
    margin: 0 0px 0 3px;
    padding: 11px 22px;
    font-size: 16px;
    text-align: center;
    white-space: nowrap;
    vertical-align: top;
    border-radius: 4px;
    border: 1px solid #e71d39;
    color: #ffffff;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .search-button:hover {
    background: #8b0916;
    -webkit-transition: all .3s;
    -moz-transition: all .3s;
    transition: all .3s;
}

.eateasy-location-search .location-search-box-outer .eateasy-main-search .current-location{
    background: #F3F3F3;
    border-radius: 4px;
    margin-top: 12px;
    text-align: center;
    font-size: 14px;
    padding: 10px;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .current-location a{
    font-weight: 600;
    color: #999999;
}
.eateasy-location-search .location-search-box-outer .eateasy-main-search .current-location a i{
    color: #E71C38;
}

/* // Medium devices (tablets, less than 992px) */
@media (max-width: 991.98px) {
    .eateasy-location-search .location-search-box-outer .eateasy-main-search .search-bar{
        width: 100%;
        margin-bottom: 4px;
    }
    .eateasy-location-search .location-search-box-outer .eateasy-main-search .search-bar .search-field{
        width: 100% !important;
        margin: 0px;
    }
    .eateasy-location-search .location-search-box-outer .eateasy-main-search .search-button{
        width: 100% !important;
        margin: 0px;
    }
 }




.home-slider-wrapper{
    padding: 15px 0 50px 0;
}
.swiper-container {
    width: 100%;
    height: auto;
  }
  .swiper-slide {
    text-align: center;
    font-size: 18px;
    background: #fff;

  }
  .swiper-slide img{
    width: 100%;
    border-radius: 10px;
  }
  .swiper-pagination{
    position: relative;
    bottom: 0px;
    padding: 15px 0;
  }
  .swiper-pagination-bullet {
    width: 10px;
    height: 10px;
}
.swiper-pagination-bullet-active{
    background: #333333;
}


	</style>
	
	
	
	
		<style>


        .tabs {
            display: flex;
            justify-content: center;
            width: 100%;
            max-width: 500px;
        }

        .tab {
            font-size: 16px;
            padding: 15px 60px;
            cursor: pointer;
        }

        .tab.active {
            background-color: rgb(250, 97, 9);
        }

        .content {
            width: 100%;
            max-width: 500px;
            margin-top: 25px;
        }

        .content-item {
            display: none;
            padding: 50px;
            border: 1px solid #ccc;
        }

        .content-item.active {
            display: flex;
            justify-content: center;
        }
	
	
	
	
	
	
	
	</style>
	
	
	<style>
	
.warpper{
  display:flex;
  flex-direction: column;
  align-items: center;
}
.tab{
  cursor: pointer;
  padding:10px 20px;
  margin:0px 2px;
  background:#000;
  display:inline-block;
  color:#fff;
  border-radius:3px 3px 0px 0px;
  box-shadow: 0 0.5rem 0.8rem #00000080;
}
.panels{
  background:#fffffff6;
  box-shadow: 0 2rem 2rem #00000080;
  min-height:200px;
  width:100%;
  max-width:500px;
  border-radius:3px;
  overflow:hidden;
  padding:20px;  
}
.panel{
  display:none;
  animation: fadein .8s;
}
@keyframes fadein {
    from {
        opacity:0;
    }
    to {
        opacity:1;
    }
}
.panel-title{
  font-size:1.5em;
  font-weight:bold
}
.radio{
  display:none;
}
#one:checked ~ .panels #one-panel,
#two:checked ~ .panels #two-panel,
#three:checked ~ .panels #three-panel{
  display:block
}
#one:checked ~ .tabs #one-tab,
#two:checked ~ .tabs #two-tab,
#three:checked ~ .tabs #three-tab{
  background:#fffffff6;
  color:#000;
  border-top: 3px solid #000;
}
	
	
	
	
	</style>
	
	
	
	
	
	
  </head>
<body onLoad="disableClick()">
  
  
  <!-- Category container starts here -->
  
  


  <section class="eateasy-home-banner no-banner">
  
  
</section>

<section class="eateasy-location-search bg-white">
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="location-search-box-outer">
<ul class="main-category-box" id="mainCategoryBoxHome">
<li class="main-category-button active 1" id="homeDeliveryTabLi" onClick="setHomepageDelivery('food')">
<a href="#food">
<div class="category-icon"><img src="img/Delivery.png" alt=""></div>
<div class="category-name">Delivery</div>
</a>
</li>
<li class="main-category-button  2" id="homeGroceryTabLi" onClick="setHomepageDelivery('grocery')">
<a href="#grocery">
<div class="category-icon"><img src="img/respickup.png" alt=""></div>
<div class="category-name">Pick Up</div>
</a>
</li>

</ul>
<div class="clear"></div>
<div class="col-md-12 col-lg-8 col-lg-offset-2">
<div class="eateasy-main-search" id="eateasyMainSearchHomeDiv">
<h1><span id="homePageTabHeadText">Find Your Favourite Food</span></h1>
<form id="frmHomeSearchNew" action="https://www.eateasy.ae/dubai/restaurants/search/ " class="has-validation-callback">
<input type="hidden" id="tyepSelectedTabHome" name="tyepSelectedTabHome" value="food" />


<div class="ui icon big input" id="locator-input-section">
            <input type="text" placeholder="Enter Your Address" id="autocomplete" />
            <i aria-hidden="true" class="dot circle outline link icon" id="locator-button"></i>
        </div>

</form>
</div>
<ul class="main-category-box" id="mainCategoryBoxHome">
<li class="main-category-button active 1">
<a href="index.php">
<div class="category-icon"><img src="img/food.png" alt=""></div>
<div class="category-name">Food</div>
</a>
</li>
<li class="main-category-button  2">
<a href="groceryindex.php">
<div class="category-icon"><img src="img/groc.png" alt=""></div>
<div class="category-name">Grocery</div>
</a>
</li>

</ul>
</div>
</div>
</div>
</div>
</div>
</section>






















<div class="modal fade" id="view-categories" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-body">
<ul class="main-category-box">
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/design/Delivery.png" alt=""></div>
<div class="category-name">Food Delivery</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/design/grocery.png" alt=""></div>
<div class="category-name">Grocery Delivery</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/design/codes.png" alt=""></div>
<div class="category-name">Codes (dine in)</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/SmartMeals.png" alt=""></div>
<div class="category-name">Smart Meals</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/Pharmacy.png" alt=""></div>
<div class="category-name">Pharmacy</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/Flower.png" alt=""></div>
<div class="category-name">Flower Shop</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/cake.png" alt=""></div>
<div class="category-name">Cake Shop</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/petshop.png" alt=""></div>
<div class="category-name">Pet Shop</div>
</li>
</a>
<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/specialityStores.png" alt=""></div>
<div class="category-name">Speciality stores</div>
</li>
</a>

<a href="">
<li class="main-category-button">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/Electronics.png" alt=""></div>
<div class="category-name">Electronics</div>
</li>
</a>
</ul>
</div>
</div>
</div>
</div>
<div class="modal main-search-modal fade" id="city-modal-id" tabindex="-1" role="dialog" aria-labelledby="locationModal" aria-hidden="true">
<div class="modal-dialog">
<a href="#" class="close-link" data-dismiss="modal"><i class="fa fa-times-circle-o"></i></a>
<div class="modal-content modal-popup">
<div class="search-form">
<h2 class="theme-box-title">Select your city</h2>
<div class="search-form-inner">
<form method="post">
<div class="right-inner-addon ">
<i class="fa fa-search"></i>
<input id="mycitymobile" class="form-control search-field city" />
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="modal main-search-modal fade" id="location-modal-id" tabindex="-1" role="dialog" aria-labelledby="locationModal" aria-hidden="true">
<div class="modal-dialog">
<a href="#" class="close-link" data-dismiss="modal"><i class="fa fa-times-circle-o"></i></a>
<div class="modal-content modal-popup">
<div class="search-form">
<h2 class="theme-box-title">Enter your location</h2>
<div class="search-form-inner">
<form method="post">
<div class="right-inner-addon ">
<i class="fa fa-search"></i>
<input id="mylocationmobile" class="form-control search-field location" />

<div class="ui icon big input" id="locator-input-section">
            <input type="text" placeholder="Enter Your Address" id="autocomplete" />
            <i aria-hidden="true" class="dot circle outline link icon" id="locator-button"></i>
        </div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBM0hg56Cqi2DQ4Qe5ziTc58kAlA4cPy0I&libraries=places">
</script>
<script src="app.js"></script>
<div class="modal city-modal fade" id="page-load-city-modal-id" tabindex="-1" role="dialog" aria-labelledby="locationModal" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content modal-popup">
<div class="details">
<h4>Order Food Online for</h4>
<h2>Delivery, Takeaway</h2>
<h4>Restaurants in UAE</h4>
</div>
<div class="city-form">
<h3 class="theme-box-title">Choose your city <a href="#" class="close-link" data-dismiss="modal"><i class="fa fa-times-circle-o"></i></a>
</h3>
<div class="city-form-inner">
<form method="post" action="">
<label>
<input type="radio" name="lang" checked class="icheck" id="englishURL"> English
</label>
<label>
<input type="radio" name="lang" class="icheck" id="arabicURL">العربية
</label>
<div id="eng">
<a id="currentLocation" href="#">
<i class="fa fa-location-arrow" aria-hidden="true"></i>
Find restaurants nearby my location
</a>
<a href="">Dubai</a>
<a href="">Abu Dhabi</a>
<a href="">Sharjah</a>
<a href="">Al Ain</a>
<a href="">Ajman</a>
<a href="">Ras Al Khaimah</a>
<a href="">Fujairah</a>
<a href="">Umm Al Quwain</a>
</div>
<div id="arabic" style="display:none ;">
<a id="currentLocation">
<i class="fa fa-location-arrow" aria-hidden="true"></i>
اوجد المطاعم القريبة من موقعي
</a>
<a href="">دبي</a>
<a href="">أبو ظبي</a>
<a href="">الشارقة</a>
<a href="">العين</a>
<a href="">عجمان</a>
<a href="">رأس الخيمة</a>
<a href="">الفجيرة‎‎</a>
<a href="">أم القيوين</a>
</div>
</form>
</div>
</div>
</div>
</div>
</div>


<div class="modal login-modal fade" id="login-modal-id" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
</div>

<div class="modal login-modal fade" id="forgot-modal-id" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
</div>
<div class="modal login-modal fade" id="call-back-modal-id" tabindex="-1" role="dialog" aria-labelledby="myLogin" aria-hidden="true">
</div>

<div class="modal location-modal fade" id="current_location-modal-id" tabindex="-1" role="dialog" aria-labelledby="locationModal" aria-hidden="true">
</div>

<div class="modal error-modal fade" id="error-modal-id" tabindex="-1" role="dialog" aria-labelledby="errorModal" aria-hidden="true">
<div class="modal-dialog">
<a href="#" class="close-link" data-dismiss="modal"><i class="fa fa-times-circle-o" style="color: #333"></i></a>
<div class="modal-content modal-popup">
<div class="error-form-inner">
<div class="right-inner-addon ">
<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
<div id="errorMessage"></div>
</div>
<input type="submit" class="btn btn-primary" value="Ok, Got it" data-dismiss="modal">
</div>
</div>
</div>
</div>

<div class="modal error-modal fade" id="payment-modal-id" tabindex="-1" role="dialog" aria-labelledby="errorModal" aria-hidden="true">
<div class="modal-dialog">
<a href="#" class="close-link" data-dismiss="modal"><i class="fa fa-times-circle-o" style="color: #333"></i></a>
<div class="modal-content modal-popup">
<div class="error-form-inner ">
<div class="right-inner-addon ">
<div id="paymentPage"></div>
</div>
</div>
</div>
</div>
</div>
<div class="modal error-modal fade" id="card-manager-modal-id" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content modal-popup">
<div class="error-form-inner manage-card-form-inner" style="padding:20px">
<div class="right-inner-addon ">
<div id="card_manager_model"></div>
</div>
</div>
</div>
</div>
</div>

  
  
  <!--<a href="default.asp"><img src="smiley.gif" alt="HTML tutorial" style="width:42px;height:42px;"></a>-->

  

  
  <script>
  
  // Act on clicks to a elements
$("#link1").on('click', function(e) {
    // prevent the default action, in this case the following of a link
    e.preventDefault();
    // capture the href attribute of the a element
    var url = $(this).attr('href');
    // perform a get request using ajax to the captured href value
    $.get(url, function() {
        // success
    });
});
  </script>
  
  
  
  
    
  
  
  
  
  
 <!--<div class="container my-3 mb-5">
    <div class="col-lg-2 text-center bg-light my-3">     
     
    </div>
    <div class="row">

      <?php 
        $sql = "SELECT * FROM `categories`"; 
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
          $id = $row['categorieId'];
          $cat = $row['categorieName'];
          $desc = $row['categorieDesc'];
          echo '<div class="col-xs-3 col-sm-3 col-md-3">
                  <div class="card" style="width: 24rem;">
                    <img src="img/cat-'.$id. '.jpg" class="card-img-top" alt="image for this category" width="249px" height="270px">
                    <div class="card-body">
                      <h5 class="card-title"><a style="color:#d87944 !important;" href="viewProductList.php?catid=' . $id . '">' . $cat . '</a></h5>
                      <p class="card-text">' . substr($desc, 0, 30). '... </p>
                      <a href="viewProductList.php?catid=' . $id . '" class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">View All</a>
                    </div>
                  </div>
                </div>';
        }
      ?>
    </div>
</div>-->











<section class="home-slider-wrapper bg-white">
<div class="container">
<div class="row">
<div class="col-sm-12">

<div class="swiper-container">
<div class="swiper-wrapper">
<div class="swiper-slide">
<a href="">
<img class="sponsored-slide-img-home" title="128 Pizza - Website" src="img/shutterstock_2037572333.png" style="height:380px;" alt="">
</a>
</div>
<div class="swiper-slide">
<a href="">
<img class="sponsored-slide-img-home" title="129 Burger - Website" src="img/shutterstock_1921024601.png" style="height:380px;" alt="">
</a>
</div>
<div class="swiper-slide">
<a href="">
<img class="sponsored-slide-img-home" title="130 Biryani - Website" src="img/shutterstock_1930031234.png" style="height:380px;" alt="">
</a>
</div>

</div>

<div class="swiper-pagination"></div>


</div>

</div>
</div>
</div>

</section>


    <section class="services-section">
            <div class="container">
                <div class="services-sec">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="service">
                               
                                <span class="text-uppercase"><img src="img/location.png" alt="">Step 1</span>
                                   <h4 class="semi-bold text-capitalize" style=> Choose Location</h4>
                                <p style=" background: #22262F !important;">Enter your address or choose your current location using app. </p>
                            </div><!--service end-->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="service">
                              
                                <span class="text-uppercase"><img src="assets/images/icons/meat.svg" alt="">Step 2</span>
                                <h4 class="semi-bold text-capitalize">Order favorite food</h4>
                                <p style=" background: #22262F !important;">Choose your favorite food and a payment method.</p>
                            </div><!--service end-->
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6">
                            <div class="service">
                           
                                <span class="text-uppercase"><img src="assets/images/icons/box.svg" alt="">Step 3</span>
                                <h4 class="semi-bold text-capitalize">fast Delivery</h4>
                                <p style=" background: #22262F !important;">Get it delizvered right to your door in 1 hour or less.</p>
                            </div><!--service end-->
                        </div>
                    </div>
                </div><!--services end-->
            </div>
        </section>











<div class="modal error-modal fade" id="success-modal-id" tabindex="-1" role="dialog" aria-labelledby="errorModal" aria-hidden="true">
</div>

<div class="modal error-modal fade" id="cashback_modal" tabindex="-1" role="dialog" aria-labelledby="errorModal" aria-hidden="true">
</div>

<script src="https://www.eateasy.ae/styles/js/eateasy.js?v=1-10102020"></script>







<script>
       
            $.validate({
                lang: 'en',
                validateOnBlur: true,
                errorMessagePosition: 'top',
                addValidClassOnAll: true
            });
          
        </script>
<script>


     setTimeout(() => {
     getDeliveryLocationsNewModal();
     $('#menuDeliveryLocationNewModal').modal('show');
    }, 500);

                                       
                                     
                                        
                                       

                var lang='';
                  $(document).ready(function () {
  
         //getDeliveryLocations();
         setHomeDeliveryLocationsSerchBox();
      
         
         $('#favoriteRest').on('click', function(){
               var hash = window.location.hash;
               window.location.hash = this.hash;       
              clickFavoriteTab(0);         
                
         });
                
        
           $('#featuredRest').on('click', function(){
             var hash = window.location.hash;
            window.location.hash = this.hash;   
            clickFeaturedTab();
        
});   
            
            
        
 
   
        $('#recentOrder').on('click', function(){
            var hash = window.location.hash;
            window.location.hash = this.hash;
            clickRecentOrderTab();
        
        });
        
    
        
       $(document).on('click','#btn_place_similar_order',function (){
        var url = $(this).attr('rel');
        $.post(url,function(data){
            data = eval('('+data+')');
            if(data.error=='1'){
                alert('Some Error!');
            }else{
                //window.location = js_strings.site_url+'order/checkout';
                 var restCode = '';
                    if(data.restCode!=undefined && data.restCode!='' && $(window).width()<786){
                        restCode =    data.restCode;                                        
                        window.location = js_strings.site_url+'order/checkout?rc='+restCode;
                    }else{
                        window.location = js_strings.site_url+'order/checkout';
                    }
            }
            });
        
       });
      
  
        
        
        $('#easyPoints').on('click', function(){
           var hash = window.location.hash;
            window.location.hash = this.hash;
            clickEasyPointsHomeTab();
           
       
        });
        
   });
   
 function show_login_form_home(){
    $.post(js_strings.site_url+'users/login_form/',function(data){   		 
    		 data = eval('('+data+')');	       
	          $("#login-modal-id").html(data.results);
	          $("#login-modal-id").modal('show');	       
	         });    
}   
   

                
                </script>
<script>







</script>

<script>

 
/**
 *    $(document).ready(function () {
 *        $.ajaxSetup({
 *         crossDomain: true,
 *         xhrFields: {
 *             withCredentials: true
 *        }
 *       });
 *                           *                          $.post('http://beta.eateasily.com/dubai/users/retain_login/',function(data){
 *                              data=eval('('+data+')');
 *                              if(data.error==0){
 *                                window.location='https://www.eateasy.ae/dubai/users/url_login/'. data.key;
 *                              }
 *                           
 *                        });
 *                          *     });
 */
  

/**
 *    var cities= {"1":"Dubai","2":"Abu Dhabi","3":"Sharjah","4":"Al Ain","6":"Ajman","7":"Ras Al Khaimah","8":"Fujairah","9":"Umm Al Quwain"} */

  
 </script>
<script src="https://www.eateasy.ae/styles/js/eateasily-mini.js?v=23042018-1"></script>
<script src="https://www.eateasy.ae/styles/js/swiper.min.js"></script>
<style>
       
        /* ----------------  Drawer Up -------------------  */
        .errorOrderSuccess h4 {
            color: red;
            padding: 16px;
            text-align: center;
            line-height: 24px;
        }
        .drawer-up {
            position: fixed;
            height: 100%;
            width: 100%;
            left: 0;
            top: 0;
            background: rgb(0 0 0 / .50);
            overflow-y: scroll;
            
            /* Initial transforms */
            opacity: 0;
            transform: translateY(100%);
            transition: 0.5s ease;
            z-index: 1999;
        }

        .drawer-up.is-open {
            opacity: 1;
            transform: translateY(0);
        }
        .drawer-up .drawer-wrapper{
            display: flex;
            flex-direction: column;
            background-color: #ffffff;
            position: fixed;
            height: 90%;
            width: 100%;
            left: 0;
            bottom: 0;
            border-radius: 24px 24px 0 0;
            padding: 16px;

        }
        .drawer-up .drawer-wrapper .drawer-wrapper-header{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            padding: 8px 0 16px 0;
            border-bottom: solid 1px #ddd;
            
        }
        .drawer-up .drawer-wrapper .drawer-wrapper-header .drawer-title{
            font-size: 18px;
            font-weight: 600;
        }
        .drawer-up .drawer-wrapper .drawer-wrapper-header .drawer-close{
            display: inline-block;
            font: normal normal normal 14px/1 FontAwesome;
            font-size: inherit;
            text-rendering: auto;
            -webkit-font-smoothing: antialiased;
            color: #000000;
        }
        .drawer-up .drawer-wrapper .drawer-wrapper-header .drawer-close::before{
            content: "\f107";
            font-size: 24px;
        }




        .drawer-up .drawer-wrapper-body{
            flex-grow: 1;
            overflow-y: scroll;
        }
        .drawer-up .drawer-wrapper-body::-webkit-scrollbar {
            display: none;
        }
        .drawer-wrapper-body .dwb_restaurant_order_box{

        }
        .drawer-wrapper-body .dwb_restaurant_order_box .dwb_restaurant_title{
            font-size: 16px;
            font-weight: 600;
            padding: 8px 0;
        }
        .drawer-wrapper-body .dwb_restaurant_order_box .dwb_restaurant_cart_list{
            display: flex;
            flex-direction: column;
            padding-bottom: 16px;
        }
        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item{
            display: flex;
            flex-direction: column;
            padding-bottom: 16px;
        }
        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_outer{
            display: flex;
            flex-direction: row;
            width: 100%;
        }

        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_details{
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }
        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_details .cart_list_item_name{
            font-size: 14px;
            font-weight: 600;
        }
        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_details .cart_list_item_description{
            display: flex;
            flex-direction: column;
            font-size: 12px;
            color: #666666;
        }
        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_details .cart_list_item_price{
            font-size: 12px;
            color: #666666;
        }

        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_qty{
            display: flex;
            max-width: 80px;
            width: 100%;
            align-self: center;
            line-height: 24px;
            justify-content: space-between;
        }
        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_qty .fa{
            font-size: 24px;
        }
        .drawer-wrapper-body .cart_list_item_outer .cart_list_item_total_price{
            display: flex;
            /* max-width: 60px; */
            width: 100%;
            align-self: center;
            justify-content: flex-end;
            font-size: 14px;
            font-weight: 600;
        }
        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_add_comment-outer{
            display: flex;
            flex-direction: column;
            color: #666666;

        }

        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_add_comment-outer a{
            color: #999999;
            text-decoration: underline;
            font-size: 12px;
        }

        .drawer-wrapper-body .dwb_restaurant_order_box .order-box-footer{
            border-top: solid 1px #ddd;
            font-size: 14px;
            font-weight: 600;
            padding: 8px 0;
        }
        .drawer-wrapper-body .dwb_restaurant_order_box .order-box-footer .footer-row{
            display: flex;
            justify-content: space-between;
        }


        .drawer-up .drawer-wrapper-footer{
            display: flex;
            flex-direction: column;
        }
        .drawer-up .drawer-wrapper-footer .btn.btn-order{
            background-color: #099e44;
            display: block;
            width: 100%;
            color: #ffffff;
        }

        .drawer-up .drawer-wrapper-footer .checkout_footer{
            border-top: solid 1px #ddd;
            display: flex;
            flex-direction: column;
            margin-bottom: 16px;
        }

        .drawer-up .drawer-wrapper-footer .checkout_footer .apply_coupon-button{
            display: flex;
            justify-content: space-between;
            font-size: 16px;
            color: #000;
            padding: 8px 0;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .apply_coupon-button .coupon-icon{
            text-transform: uppercase;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .apply_coupon-button .coupon-icon:before{
            content: " ";
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 26'%3E%3Ctitle%3Ecoupon copy%3C/title%3E%3Cpath d='M35.8,24.91H4.2A3.32,3.32,0,0,1,.88,21.59V16.88a.58.58,0,0,1,.58-.58,3.3,3.3,0,0,0,0-6.59.58.58,0,0,1-.58-.58V4.41A3.32,3.32,0,0,1,4.2,1.09H35.8a3.32,3.32,0,0,1,3.32,3.32V9.13a.58.58,0,0,1-.58.58,3.3,3.3,0,0,0,0,6.59.58.58,0,0,1,.58.58v4.71A3.32,3.32,0,0,1,35.8,24.91ZM2,17.43v4.16A2.16,2.16,0,0,0,4.2,23.75H35.8A2.16,2.16,0,0,0,38,21.59V17.43a4.46,4.46,0,0,1,0-8.84V4.41A2.16,2.16,0,0,0,35.8,2.25H4.2A2.16,2.16,0,0,0,2,4.41V8.59a4.46,4.46,0,0,1,0,8.84Z' style='fill:%23231f20'/%3E%3Cpath d='M13,5.71a.58.58,0,0,1-.58-.58V3.58a.58.58,0,1,1,1.16,0V5.13A.58.58,0,0,1,13,5.71Z' style='fill:%23231f20'/%3E%3Cpath d='M13,18.3a.58.58,0,0,1-.58-.58V14.57a.58.58,0,0,1,1.16,0v3.15A.58.58,0,0,1,13,18.3ZM13,12a.58.58,0,0,1-.58-.58V8.28a.58.58,0,0,1,1.16,0v3.15A.58.58,0,0,1,13,12Z' style='fill:%23231f20'/%3E%3Cpath d='M13,23a.58.58,0,0,1-.58-.58V20.87a.58.58,0,1,1,1.16,0v1.55A.58.58,0,0,1,13,23Z' style='fill:%23231f20'/%3E%3Cpath d='M23.24,10.36c0,2.55-1.33,3.81-2.9,3.81s-2.8-1.21-2.82-3.64,1.32-3.78,2.92-3.78S23.24,8.05,23.24,10.36Zm-4.42.11c0,1.54.54,2.72,1.56,2.72s1.56-1.16,1.56-2.76-.43-2.69-1.56-2.69S18.82,9,18.82,10.47Zm1.41,8.78,7.11-12.5h1l-7.11,12.5Zm10.88-3.89c0,2.55-1.34,3.81-2.88,3.81S25.42,18,25.4,15.55s1.32-3.8,2.92-3.8S31.11,13.06,31.11,15.36Zm-4.43.11c0,1.55.58,2.72,1.59,2.72s1.56-1.15,1.56-2.75-.43-2.7-1.56-2.7S26.68,14,26.68,15.47Z' style='fill:%23231f20'/%3E%3C/svg%3E");
            background-size: cover;
            width: 29px;
            height: 19px;
            display: inline-block;
            vertical-align: text-bottom;
            margin-right: 8px;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .apply_coupon-button .fa{
            font-size: 24px;
            padding: 0 8px;
        }

        .drawer-up .drawer-wrapper-footer .checkout_footer .coupon_applied_section{
            display: flex;
            flex-direction: row;
            padding: 4px;
            margin: 8px 0;
            background: #eee;
            border-radius: 4px;

        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .coupon_applied_section .coupon_applied_icon{
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M12,0A12,12,0,1,0,24,12,12,12,0,0,0,12,0ZM9.8,18.164,4.515,12.881l1.761-1.761L9.8,14.642l7.925-7.926,1.761,1.761Z' fill='%2328a745'/%3E%3C/svg%3E");
            background-size: 25px;
            background-position: center;
            background-repeat: no-repeat;
            width: 30px;
            height: 30px;
            margin-right: 8px;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .coupon_applied_section .applied_coupon_code{
            font-size: 16px;
            font-weight: 600;
            flex: 1 1 0px;
            align-self: center;shutterstock_1921024601
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .coupon_applied_section .applied_coupon_action{
            display: flex;
            align-self: center;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .coupon_applied_section .applied_coupon_action .remove-icon{
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18.667' height='24' viewBox='0 0 18.667 24'%3E%3Cpath id='Icon_material-delete' data-name='Icon material-delete' d='M8.833,25.833A2.675,2.675,0,0,0,11.5,28.5H22.167a2.675,2.675,0,0,0,2.667-2.667v-16h-16Zm17.333-20H21.5L20.167,4.5H13.5L12.167,5.833H7.5V8.5H26.167Z' transform='translate(-7.5 -4.5)' fill='%239a9a9a'/%3E%3C/svg%3E%0A");
            background-size: 16px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            width: 30px;
            height: 30px;
        }




        .drawer-up .drawer-wrapper-footer .checkout_footer .svt-block{
            border: solid 1px #ddd;
            border-radius: 8px;
            padding: 8px;
            display: flex;
            flex-direction: row;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .svt-block .svt-savings-block{
            display: flex;
            width: 50%;
            flex-direction: column;
            padding-right: 8px;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .svt-block .svt-savings-block .svt-row{
            display: flex;
            justify-content: space-between;
            font-size: 12px;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .svt-block .svt-savings-block .svt-row.b{
            font-weight: 600;
        }
        .drawer-up .drawer-wrapper-footer .checkout_footer .svt-block .svt-total-amount{
            display: flex;
            flex-direction: column;
            width: 50%;
            padding-left: 8px;
            border-left: solid 1px #ddd;
            align-items: center;
            align-self: center;
            font-weight: 600;
        }



        .ee-comp.input-group{
            width: 100%;
        }
        .ee-comp.input-group .form-control{
            width: 100%;
            border-radius: 4px;
        }
        .ee-comp.input-group .input-group-append{
            position: absolute;
            top: 0px;
            right: 0px;
            z-index: 3;
        }
        .ee-comp.input-group .input-group-append .ee-button{
            background: none;
            border: none;
            padding: 8px 16px;
            font-weight: 600;
            color: #099e44;
            outline: none;

        }
        .ee-button{
            border-radius: 4px;
            padding: 2px 8px;
        }
        .ee-button.primary-button{
            background: #099E44;
            color: #ffffff;
            border: none;
        }
        .ee-button.primary-button:hover{
            background-color: #099e44 !important;
            color: #ffffff !important;
        }

        .apply_coupon_section{
            padding: 16px 0;
        }



        .ee-coupon-list{}
        .ee-coupon-list .coupon-box{
            border: solid 1px #ddd;
            padding: 8px;
            display: flex;
            flex-direction: column;
            margin-bottom: 8px;
        }
        .ee-coupon-list .coupon-box .coupon-code{
            display: flex;
            justify-content: space-between;
            font-weight: 600;
            font-size: 16px;
        }
        .ee-coupon-list .coupon-box .coupon-code .ee-button{
            font-size: 12px;
        }
        .ee-coupon-list .coupon-box .coupon-title{
            font-size: 14px;
            font-weight: 600;
        }
        .ee-coupon-list .coupon-box .coupon_description{
            font-size: 12px;
            color: #666666;
        }




        .confirm_order_section .md-contact-section{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }
        .confirm_order_section .md-contact-section .md-number{
            font-weight: 600;
        }


        .confirm_order_section .md-address-section {
            display: flex;
            overflow-x: auto;
        }
        .confirm_order_section .md-address-section::-webkit-scrollbar {
            display: none;
        }
        .confirm_order_section .md-address-section .md-address-list{
            display: flex;
            flex-direction: column;
            min-width: 200px;
            width: 200px;
            height: 80px;
            border: solid 1px #ddd;
            border-radius: 4px;
            margin-right: 8px;
            padding: 8px;
            position: relative;
        }
        .confirm_order_section .md-address-section .md-address-list.manage-button{
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: #099e44;
        }

        .confirm_order_section .md-address-section input[type=radio]:checked+label {
            border: solid 1px #099e44;
        }
        .confirm_order_section .md-address-section input[type=radio]:checked+label::before {
            content: " ";
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M12,0A12,12,0,1,0,24,12,12,12,0,0,0,12,0ZM9.8,18.164,4.515,12.881l1.761-1.761L9.8,14.642l7.925-7.926,1.761,1.761Z' fill='%2328a745'/%3E%3C/svg%3E");
            width: 16px;
            height: 16px;
            position: absolute;
            right: 8px;
            top: 8px;
            background-size: cover;
        }

        .confirm_order_section .md-address-section .md-address-list .md-address-type{
            font-size: 12px;
            font-weight: 600;
        }
        .confirm_order_section .md-address-section .md-address-list .md-address{
            font-size: 10px;
            font-weight: 400;
            line-height: 14px;
            max-height: 42px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }

        .md-delivery-schedule-section .md-delivery-button-section{
            display: flex;
            flex-direction: row;
        }
        .md-delivery-schedule-section .md-delivery-button-section .md-delivery-button{
            padding: 8px 16px;
            display: flex;
            flex: 1 1 0px;
            border-radius: 4px;
            border: solid 1px #ddd;
            justify-content: center;
            position: relative;
        }
        .md-delivery-schedule-section .md-delivery-button-section input[type=radio]:checked+label {
            border: solid 1px #099e44;
        }

        .md-delivery-schedule-section .md-delivery-button-section input[type=radio]:checked+label::before {
            content: " ";
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M12,0A12,12,0,1,0,24,12,12,12,0,0,0,12,0ZM9.8,18.164,4.515,12.881l1.761-1.761L9.8,14.642l7.925-7.926,1.761,1.761Z' fill='%2328a745'/%3E%3C/svg%3E");
            width: 16px;
            height: 16px;
            position: absolute;
            right: 8px;
            top: 8px;
            background-size: cover;
        }
        .md-delivery-schedule-section .md-delivery-text{
            font-size: 12px;
            font-weight: 600;
            padding: 8px 0;
        }
        .footer-button-section{
            display: flex;
            flex-direction: row;
        }
        .footer-button-section .md-footer-button{
            display: flex;
            flex: 1 1 0px;
            flex-direction: column;
            padding: 8px;
            border-radius: 4px;
            text-align: center;
            height: 48px;
            cursor: pointer;
            justify-content: center;
        }
        .footer-button-section .md-footer-button .primary-text{
            font-weight: 600;
            font-size: 12px;
        }
        .footer-button-section .md-footer-button .secondary-text{
            font-size: 10px;
        }
        .footer-button-section .md-footer-button.green{
            background-color: #099e44;
            color: #ffffff;
        }
        .footer-button-section .md-footer-button.gray{
            background-color: #E7E7E7;
            color: #333333;
        }



        .select_payment_section .md-payment-type-section .md-payment-type{
            border-radius: 4px;
            border: solid 1px #ddd;
            padding: 8px;
            display: flex;
            flex-direction: row;
            margin-bottom: 8px;
            cursor: pointer;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon{
            min-width: 40px;
            background-size: 30px;
            background-position: center;
            background-repeat: no-repeat;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon.master{
            background-image: url(https://www.eateasy.ae/styles/img/master-card.png);
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon.visa{
            background-image: url(https://www.eateasy.ae/styles/img/visa-card.png);
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon.amex{
            background-image: url(https://www.eateasy.ae/styles/img/amex-card.png);
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon.add-card{
            background-image: url(https://www.eateasy.ae/styles/img/add-card.png);
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-icon.cash{
            background-image: url(https://www.eateasy.ae/styles/img/cash-icon.png);
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-type-details{
            display: flex;
            flex: 1 1 0px;
            flex-direction: column;
            padding-left: 8px;
            justify-content: center;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-type-details .primary-text{
            font-size: 14px;
            font-weight: 600;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-type-details .secondary-text{
            font-size: 12px;
            font-weight: 400;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-action{
            min-width: 40px;
            max-width: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .select_payment_section .md-payment-type-section .md-payment-type .payment-action .secure-icon{
            width: 40px;
            height: 40px;
            background-image: url(https://www.eateasy.ae/styles/img/secure.png);
            background-size: 25px;
            background-position: center;
            background-repeat: no-repeat;
            display: block;
        }



        .update-mobile-section{
            padding:8px 0;
        }
        .update-mobile-section .update-mobile-box{
            display: flex;
            flex-direction: row;
        }
        .update-mobile-section .update-mobile-box .update-mobile-code{
            max-width: 60px;
        }
        .update-mobile-section .update-mobile-box .update-mobile-number{
            display: flex;
            flex: 1 1 0px;
        }




        .manage-delivery-address-section {}
        .manage-delivery-address-section .delivery-address-list{
            display: flex;
            flex-direction: row;
            border: solid 1px #ddd;
            padding: 8px;
            border-radius: 4px;
            margin-bottom: 8px;
            min-height: 40px;
            cursor: pointer;
        }
        .manage-delivery-address-section .delivery-address-list .address-icon{
            min-width: 40px;
            min-height: 40px;
            background-size: 30px;
            background-position: center;
            background-repeat: no-repeat;
        }
        .manage-delivery-address-section .delivery-address-list .address-icon.add{
            background-image: url(https://www.eateasy.ae/styles/img/add-card.png);
        }
        .manage-delivery-address-section .delivery-address-list .address-details{
            display: flex;
            flex-direction: column;
            flex: 1 1 0px;
            align-self: center;
        }
        .manage-delivery-address-section .delivery-address-list .address-details .primary-text{
            font-size: 14px;
            font-weight: 600;
        }
        .manage-delivery-address-section .delivery-address-list .address-details .secondary-text{
            font-size: 12px;
        }
        .manage-delivery-address-section .delivery-address-list .address-details .label-text{
            color: #099e44;
            font-size: 12px;
        }
        .manage-delivery-address-section .delivery-address-list .address-list-action{
            min-width: 40px;
            max-width: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }



        .add-delivery-address-section{
            padding: 8px 0px;
        }
        .add-delivery-address-section .address-category{
            display: flex;
            flex-direction: row;
            padding: 8px 0;
            margin-bottom: 10px;

        }
        .add-delivery-address-section .address-category .ee-comp{
            display: flex;
            align-items: center;
            margin-right: 16px;
        }
        .add-delivery-address-section .address-category .ee-comp span{
            padding: 0 8px;
        }

        .add-delivery-address-section .address-category .ee-comp label{
            border: solid 1px #ddd;
        }









        /* --------------- Eateasy Components --------------------- */
        .ee-py-01{padding: 8px 0;}
        .ee-py-02{padding: 16px 0;}
        .ee-mr-01{margin-right: 8px;}
        .ee-ml-01{margin-left: 8px;}
        .ee-hidden{display: none;}


        .ee-tag{
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .ee-tag-red{
            border: solid 1px #E71C38;
            color: #E71C38;
        }
        .ee-comp.ee-heading-01{
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .ee-comp.ee-sec-head{
            display: flex;
            font-size: 16px;
            justify-content: space-between;
            background-color: #eeeeee;
            padding: 4px 4px;
        }
        .ee-comp.ee-sec-head-no-bg{
            display: flex;
            font-size: 16px;
            justify-content: space-between;
            padding: 4px 0px;
        }
        .ee-comp.ee-button{
            border-radius: 4px;
            padding: 4px 8px;
            background: none;
            border: none;
            font-size: 12px;
        }
        .ee-comp.ee-button.primary-button{
            background: #099E44;
            color: #ffffff;
            border: none;
        }

        .ee-icon-gear::before{
            content: "";
            background-size: cover;
            width: 15px;
            height: 15px;
            vertical-align: text-bottom;
            display: inline-block;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='22.09' height='24' viewBox='0 0 22.09 24'%3E%3Cg transform='translate(-2.424 -1.25)'%3E%3Cg transform='translate(2.423 1.25)'%3E%3Cpath d='M24.11,16.541a2.3,2.3,0,0,1-.588-2.309V13.3c0-.98-.008-1.019-.008-1.019a2.332,2.332,0,0,1,.58-2.359c.534-.305.559-1.276.055-2.157L23.6,6.811c-.5-.883-1.358-1.352-1.9-1.045a2.568,2.568,0,0,1-2.43-.588l-1.717-.987c-.938-.387-1.707-1.207-1.707-1.822S15.019,1.25,14,1.25H12.937c-1.015,0-1.846.5-1.846,1.1s-.772,1.409-1.714,1.785l-1.8.984A2.538,2.538,0,0,1,5.2,5.739c-.514-.292-1.346.189-1.85,1.071l-.544.953C2.306,8.644,2.3,9.6,2.8,9.885s.73,1.332.508,2.322c0,0-.019.085-.019,1.089v.963c.211.993-.018,2.034-.509,2.315s-.48,1.23.024,2.112l.544.953c.5.882,1.316,1.374,1.8,1.1a2.526,2.526,0,0,1,2.33.648l1.89,1.068c.941.38,1.713,1.164,1.713,1.744s.831,1.053,1.846,1.053H14c1.015,0,1.846-.482,1.846-1.071s.766-1.389,1.7-1.78l1.811-1.07a2.55,2.55,0,0,1,2.382-.618c.515.294,1.349-.187,1.852-1.069l.546-.953C24.65,17.806,24.635,16.839,24.11,16.541Zm-10.739,3.2A6.545,6.545,0,1,1,19.916,13.2,6.545,6.545,0,0,1,13.371,19.745Z' transform='translate(-2.423 -1.25)' fill='%23949494'/%3E%3C/g%3E%3Cg transform='translate(10.709 10.407)'%3E%3Ccircle cx='2.729' cy='2.729' r='2.729' fill='%23949494'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }








        .ee-comp label {
            -webkit-appearance: none;
            background-color: #ffffff;
            border: 1px solid #ffffff;
            width: 24px;
            height: 24px;
            border-radius: 50px;
            display: inline-block;
            position: relative;
            vertical-align: middle;
            cursor: pointer;
            margin: 0;
            padding: 0;
        }
        .ee-comp input[type="radio"] {
            display: none;
            cursor: pointer;
        }
        .ee-comp input:checked + label:after {
            content: '';
            width: 24px;
            height: 24px;
            position: absolute;
            top: -1px;
            left: -1px;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath d='M12,0A12,12,0,1,0,24,12,12,12,0,0,0,12,0ZM9.8,18.164,4.515,12.881l1.761-1.761L9.8,14.642l7.925-7.926,1.761,1.761Z' fill='%2328a745'/%3E%3C/svg%3E");
        }






        input.ee-adaptive-textbox[type="text"] {
            box-sizing: border-box;
            width: 100%;
            margin: 0 0 1em;
            padding: 6px;
            border: 1px solid #bababa;
            border-radius: 4px;
            background: #fff;
            font-size: 16px;
            resize: none;
            outline: none;
        }
        input.ee-adaptive-textbox[type="text"]:focus {
            border-color: #099E44;
        }
        input.ee-adaptive-textbox[type="text"]:focus + label[placeholder]:before {
            color: #099E44;
        }
        input.ee-adaptive-textbox[type="text"]:focus + label[placeholder]:before,
        input.ee-adaptive-textbox[type="text"]:valid + label[placeholder]:before {
            transition-duration: .2s;
            transform: translate(0, -1.6em) scale(0.9, 0.9);	
            font-weight: bold;
        }
        input.ee-adaptive-textbox[type="text"]:valid {
            border-color: #099E44;
        }
        input.ee-adaptive-textbox[type="text"]:valid + label[placeholder]:before {
            color:#099E44;
        }
        input.ee-adaptive-textbox[type="text"]:invalid + label[placeholder][alt]:before {
            content: attr(alt);
        }
        input.ee-adaptive-textbox[type="text"] + label[placeholder] {
            display: block;	
            pointer-events: none;
            line-height: 1.25em;
            margin-top: calc(-3em - 2px);
            margin-bottom: calc((3em - 1em) + 2px);
        }
        input.ee-adaptive-textbox[type="text"] + label[placeholder]:before {
            content: attr(placeholder);
            display: inline-block;
            margin: 0 calc(0.5em + 2px);
            padding: 0 2px;
            color: #7d7d7d;
            white-space: nowrap;
            transition: 0.3s ease-in-out;
            background-image: linear-gradient(to bottom, #ffffff, #ffffff);
            background-size: 100% 5px;
            background-repeat: no-repeat;
            background-position: center;
        }

                /*29/11/2020 Cart*/
        .rest-cart-section{
        }
        .rest-cart-section .rest-checkout-box{
            border: solid #ddd 1px;
            padding: 8px;
            margin: 8px 0;
            position: relative;
        }
        .rest-cart-section .rest-checkout-box .rest-name{
            font-weight: 600;
            font-size: 16px;
            line-height: 30px;
        }
        .rest-cart-section .rest-checkout-box .rest-order-details{
            font-size: 12px;
                padding: 4px 0;
        }
        .rest-cart-section .rest-checkout-box .rest-order-items{
            font-size: 14px;
            padding-bottom: 8px;
        }
        .rest-cart-section .rest-checkout-box .rest-fbox{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-top: solid 1px #ddd;
        }
        .rest-cart-section .rest-checkout-box .rest-fbox.total{
            font-weight: 600;
        }
        .rest-cart-section .rest-checkout-box .location-box .btn-location{
            display: flex;
            justify-content: center;
            align-items: center;
            color: #000;
            margin-bottom: 8px;
        }
        .location-icon{
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='18.643' height='25.857' viewBox='0 0 18.643 25.857'%3E%3Cpath id='Icon_ionic-md-pin' data-name='Icon ionic-md-pin' d='M15.321,2.25a8.512,8.512,0,0,0-8.571,8.4c0,6.3,8.571,15.6,8.571,15.6s8.571-9.3,8.571-15.6A8.512,8.512,0,0,0,15.321,2.25Zm0,11.4a3,3,0,1,1,3.061-3A3,3,0,0,1,15.321,13.65Z' transform='translate(-6 -1.5)' fill='none' stroke='%232c2c2c' stroke-width='1.5'/%3E%3C/svg%3E%0A");
            background-size: 16px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            width: 30px;
            height: 30px;
        }
        .rest-cart-section .rest-checkout-box .rest-checkout-footer .btn-checkout{
            background-color: #099e44;
            color: #fff;
            width: 100%;
        }
        .rest-cart-section .rest-checkout-box .cart-remove{
            position: absolute;
            right: 0px;
            top: 0px;
        }
        .close-icon{
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 30 30'%3E%3Cg id='Group_2796' data-name='Group 2796' transform='translate(-20608 -18529)'%3E%3Cg id='Ellipse_369' data-name='Ellipse 369' transform='translate(20608 18529)' fill='none' stroke='%23707070' stroke-linecap='round' stroke-width='1.5'%3E%3Ccircle cx='15' cy='15' r='15' stroke='none'/%3E%3Ccircle cx='15' cy='15' r='14.25' fill='none'/%3E%3C/g%3E%3Cline id='Line_178' data-name='Line 178' x2='12' y2='12' transform='translate(20617.5 18538.5)' fill='none' stroke='%23707070' stroke-linecap='round' stroke-width='1.5'/%3E%3Cline id='Line_179' data-name='Line 179' x1='12' y2='12' transform='translate(20617.5 18538.5)' fill='none' stroke='%23707070' stroke-linecap='round' stroke-width='1.5'/%3E%3C/g%3E%3C/svg%3E%0A");
            background-size: 24px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            width: 30px;
            height: 30px;
        }
        .location-select-body{
        }
        .location-select-body .select-locations{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            color: #555;
            border-bottom: solid 1px #ddd;
            font-size: 16px;
            flex-direction: row;
        }
        .location-select-body .select-locations .select-location-name{
            align-items: center;
            display: flex;
            min-width: 0;
        }
        .location-select-body .select-locations .select-location-name .lc-name{
            font-weight: 600;
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }
        .location-select-body .select-locations .min-order{
            display: flex;
            align-items: center;
            white-space: nowrap;
        }
        .address-loc-section .map-box{
            width: 100%;
            height: calc(100% - 50px);
            background-color: #eee;
        }
        #Address_Location_Drawer .loc-details-box{
            display: flex;
            flex-direction: column;
            padding: 8px 0;
        }
        #Address_Location_Drawer .loc-details-box .loc-label{
            font-size: 12px;
            color: #666666;
        }
        #Address_Location_Drawer .loc-details-box .sel-location{
            font-size: 16px;
            font-weight: 600;
            color: #555;
        }
        .address-loc-section .find-me-btn .find-me{
            background-size: 18px;
            width: 18px;
            height: 18px;
        }
        .find-me{
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 16 16'%3E%3Cpath id='Icon_material-my-location' data-name='Icon material-my-location' d='M9.5,6.591A2.909,2.909,0,1,0,12.409,9.5,2.908,2.908,0,0,0,9.5,6.591ZM16,8.773A6.541,6.541,0,0,0,10.227,3V1.5H8.773V3A6.541,6.541,0,0,0,3,8.773H1.5v1.455H3A6.541,6.541,0,0,0,8.773,16v1.5h1.455V16A6.541,6.541,0,0,0,16,10.227h1.5V8.773ZM9.5,14.591A5.091,5.091,0,1,1,14.591,9.5,5.087,5.087,0,0,1,9.5,14.591Z' transform='translate(-1.5 -1.5)' fill='%23313942'/%3E%3C/svg%3E%0A");
            background-size: 24px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            width: 30px;
            height: 30px;
        }

                .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_add_comment-outer .item_comments{
            padding: 4px 8px;
            background: #EBEBEB;
            border-radius: 4px;
            display: flex;
            flex-direction: row;
            width: max-content;
        }
        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_add_comment-outer .item_comments .comment-text{
            align-self: center;
        }
        .drawer-wrapper-body .dwb_restaurant_cart_list .dwb_restaurant_cart_list_item .cart_list_item_add_comment-outer .item_comments .ee-button{
            border: none;
        }
        .ee-edit-icon{
            background-image: url("data:image/svg+xml,%3Csvg id='pen' xmlns='http://www.w3.org/2000/svg' width='22' height='22' viewBox='0 0 22 22'%3E%3Cpath id='Path_5778' data-name='Path 5778' d='M21.376,3.961,18.04.625a2.132,2.132,0,0,0-3.015,0L1.059,14.59a.857.857,0,0,0-.243.491L.008,21.028a.857.857,0,0,0,.964.964l5.947-.807a.857.857,0,0,0,.491-.243L21.376,6.976a2.132,2.132,0,0,0,0-3.015ZM6.4,19.525l-4.545.617L2.475,15.6l9.9-9.9L16.3,9.629ZM20.164,5.764,17.511,8.417,13.583,4.489l2.653-2.653a.418.418,0,0,1,.592,0l3.336,3.336a.418.418,0,0,1,0,.591Z' transform='translate(0 0)' fill='%236b6b6b'/%3E%3C/svg%3E%0A");
            background-size: 16px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            width: 24px;
            height: 24px;
        }

 </style>
<style>
    .map-below-span-all{
        display: block;
        padding-top: 10px;
    }
  #error-modal-id{
    z-index: 9999999;
  }
    .ee-pt-1{padding-top: 8px;}
    .ee-pt-2{padding-top: 16px;}
    .ee-pt-3{padding-top: 24px;}
    .verify_contact_body a{
        color: #555555;
    }
    .otp-form{
        text-align: center;
        padding-bottom: 16px;
    }
    .text-center{
        text-align: center;
    }
    .digit-group input {
        width: 30px;
        height: 50px;
        background-color: #ffffff;
        border: none;
        border-bottom: solid 2px #000;
        line-height: 50px;
        text-align: center;
        font-size: 24px;
        font-family: 'Raleway', sans-serif;
        font-weight: 200;
        color: #000;
        margin: 0 2px;
    }
    .prompt {
        margin-bottom: 20px;
        font-size: 20px;
        color: white;
    }
    .footer-mobile-checkout-map-btn{
        margin-top: 5px;
    }
</style>
<style>
  .error{
      color:red;
  }
  .locationMapModalInputDiv{
    margin-bottom: 12px;
  }
    .address-tile{
        border: solid #DDDDDD 1px;
        padding: 16px;
        display: flex;
        flex-direction: column;
        border-radius: 8px;
        margin:15px 0 0 0;
    }
    .address-tile.selected{
        /*background: #959595;*/
        border: 2px solid #11b954;
        /*color: #fff;*/
        padding:   15px 16px;
    }
    .wadd-action .btn{
        padding: 3px 16px;
    }
    .wadd-type{
        font-weight: 600;
        font-size:15px;
        display: flex;
        justify-content: space-between;
        align-content: center;
    }
    .wadd-check{}
    .wadd-add{
        margin-bottom:10px;
        font-weight: 400;
        min-height:54px;
    }

    @media (min-width: 768px){
        .modal-dialog-common {
            width: 600px;
            max-width: unset !important;
            margin: 30px auto;
        
        }
    }
    
</style>
<input type="hidden" id="mapNewData-lat" value="0" />
<input type="hidden" id="mapNewData-lng" value="0" />
<input type="hidden" id="triggerFodSrchClose" value="0" />
<script src="https://www.eateasy.ae/styles/js/header.js?v=30122020-2"></script>

<script type="text/javascript">
    var js_strings = {
    site_url: "https://www.eateasy.ae/dubai/",
    lang_js_1:"Select Delivery Location",
    lang_js_2:"Update your address",
    lang_js_3:"Add your address",
    lang_js_4:"Signup In two Minutes",
    lang_js_5:"User Login",
    lang_js_6:"Choose your options here",
    lang_js_7:"This food is not available now!",
    lang_js_8:"Restaurant is closed now!",
    lang_js_9:"Please fill all the Mandatory field  ( marked as *)",
    lang_js_10:"Choose your options here",
    lang_js_11:"Please enter your phone number and click save",
    lang_js_12:"You donot have sufficient Easy Points to use for this order! Please choose other payment option",
    lang_js_13:"Please select your location",
    lang_js_14:"Please enter registered Email id OR Mobile number",
    lang_js_15:"Please enter your name",
    lang_js_16:"Please enter your mobile number",
    lang_js_17:"Please enter valid amount",
    lang_js_18:"Please enter valid coupon code",
    lang_js_19:"Max limit reached",
    lang_js_20:" is required",
    lang_js_21:" are required",
    lang_js_22:"Added as favorite",
    lang_js_23:"Removed as favorite",

    lang_js:""
    };
</script>
<script>
            //recentLocNew
            var locSearch="https://www.eateasy.ae/dubai/restaurants/search/dlocations-";
            function funGotoLoc(){
                             var fetchClass="home"; 
                var newLoc= locSearch;
                //alert(fetchClass);
                var inputRel = $("#menuDeliveryLocationNewModalInput").attr('rel');

                var inputVal = $("#menuDeliveryLocationNewModalInput").val();
                if( inputVal.trim()!='' && inputVal!=undefined){
                    $('#locTopLocErr').hide();
                 var mainInput =inputVal;
                    inputVal = inputVal.toLowerCase();
                    inputVal= inputVal.replace(/ /g, '-'); 
                    //inputVal.split(' ').join('-'); 
                    newLoc= newLoc+inputVal+'-'+inputRel;   $('#preloader').show();
                 
                     $.post(js_strings.site_url+'home/setNewLocation/'+inputRel,{mainInput:mainInput  } ,function(data){   
                         //console.log(parseInt(data),data);
                         if(parseInt(data)){
                           
                            $('#error-loction-new-modal').hide();
                            if(fetchClass=='restaurants'){
                                window.location.href="https://www.eateasy.ae/dubai/restaurants/search/";
                            }else{
                                window.location.reload();
                            }
                          
                         }else{ 
                             $('#menuDeliveryLocationNewModalInput').val('');
                            $('#error-loction-new-modal').show();
                         }
                        //window.location.reload(); //href=newLoc;
                     });
                }else{
                    $('#locTopLocErr').show();
                }

            }

            function funGotoLocHome(className='homeInputLocation'){
                var newLoc= locSearch;
                var inputRel = $("."+className).attr('rel');

                var inputVal = $(".homeInputLocation").val(); 
                var typeVal = $("#tyepSelectedTabHome").val();
                if( inputVal.trim()!='' && inputVal!=undefined){
                 var mainInput =inputVal;
                    inputVal = inputVal.toLowerCase();
                    inputVal= inputVal.replace(/ /g, '-'); 
                    //inputVal.split(' ').join('-'); 
                    newLoc= newLoc+inputVal+'-'+inputRel;   $('#preloader').show();
                     $('#preloader').show();
                     $.post(js_strings.site_url+'home/setNewLocation/'+inputRel,{mainInput:mainInput,type:typeVal  } ,function(data){   
                        //window.location.href=newLoc;
                        //$('#preloader').hide();
                        if(typeVal=='food'){
                            $('#frmHomeSearchNew').submit();
                        }
                        else if(typeVal=='cake'){
                            //$('#preloader').show();
                                // $.get(js_strings.site_url+'home/getCusineCake',function(data){  });
                                 window.location.href=data;
                            // $('#preloader').hide();

                               
                           }
                        else if(typeVal=='charity'){
                            window.location.href="https://www.eateasy.ae/dubai/charity/charity_package"; 
                        }
                        else if(typeVal=='giftcard'){
                            window.location.href="https://www.eateasy.ae/dubai/giftcard/gift_themes"; 
                        }else{
                            console.log("https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType="+typeVal);
                            window.location.href="https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType="+typeVal; 
                        }
                     

                     });
                }else{
                    $('#error-modal-id').modal('show');
                    $('#errorMessage').text('Please select your location');
                }
            }

            function funHashTriggerClick(type){
                if(type=='grocery'){
                    $('#homeGroceryTabLi').trigger('click');
                } 
                else if(type=='pharmacy'){
                    $('#homePharmacyTabLi').trigger('click');
                }else{
                    $('#homeDeliveryTabLi').trigger('click');
                }

            }
           
            function getDeliveryLocationsNewModal() {
                $('#locTopLocErr').hide();
                ajaxLoadFlag =false; 
                $('#preloader').show();
                    $.get(js_strings.site_url+'home/delivery/0/dlocations/0',function(data){   
                    
                    data = eval('('+data+')');
                    dlocations = data;
                    ajaxLoadFlag =true; 
                    $('#preloader').hide();
                            
                                    ///Autofill search main - location /////
                        var input = document.getElementById("menuDeliveryLocationNewModalInput");
                        var comboplete_location_main = new Awesomplete(input, {
                            list: dlocations,
                            minChars: 0,
                            maxItems: 1000,
                            sort:function (a, b) {
                                            return false;
                                        },
                            replace:function (text) {
                                        this.input.value = text;
                                        $('#menuDeliveryLocationNewModalInput').attr('rel',this.suggestions[this.index]['value']); 
                                                                
                                    }
                        });

                
                        Awesomplete.$('#menuDeliveryLocationNewModalInput').addEventListener("click", function () {
                            if (comboplete_location_main.ul.childNodes.length === 0) {
                                comboplete_location_main.minChars = 0;
                                comboplete_location_main.evaluate();
                                
                            } else if (comboplete_location_main.ul.hasAttribute('hidden')) {
                                comboplete_location_main.open();
                            }
                        });
                        $("#menuDeliveryLocationNewModalInput").parent('.awesomplete').parent('.awesomplete').removeClass('width-40');
                        $("#menuDeliveryLocationNewModalInput").parent('.awesomplete').parent('.awesomplete').addClass('width-100');
                        $("#menuDeliveryLocationNewModalInput").parent('.awesomplete').addClass('width-100');
                        $('#menuDeliveryLocationNewModal').modal('show');
                        
                        //   $("#city").parents('.awesomplete').addClass('width-18');
                        //  $("#menuDeliveryLocationNewModalInput").parents('.awesomplete').addClass('width-40');
                        //  $(".menu-dlocation-input").parents('.awesomplete').addClass('width-100');

                    });

           


           }


           function setHomeDeliveryLocationsSerchBox() {
               // ajaxLoadFlag =false; 
                    $.get(js_strings.site_url+'home/delivery/0/dlocations/0',function(data){   
                    
                    data = eval('('+data+')');
                    dlocations = data;
                    //ajaxLoadFlag =true; 
                    //$('#preloader').hide();
                   
                                    ///Autofill search main - location /////
                        var input = document.getElementById("location");
                        var comboplete_location_main = new Awesomplete(input, {
                            list: dlocations,
                            minChars: 0,
                            maxItems: 1000,
                            sort:function (a, b) {
                                            return false;
                                        },
                            replace:function (text) {
                                        this.input.value = text;
                                       
                                        $('#location').attr('rel',this.suggestions[this.index]['value']); 
                                                                
                                    }
                        });

                
                        Awesomplete.$('#location').addEventListener("click", function () {
                            if (comboplete_location_main.ul.childNodes.length === 0) {
                                comboplete_location_main.minChars = 0;
                                comboplete_location_main.evaluate();
                                
                            } else if (comboplete_location_main.ul.hasAttribute('hidden')) {
                                comboplete_location_main.open();
                            }
                        });

                        Awesomplete.$('#location').addEventListener("change", function () {
                            if (comboplete_location_main.ul.childNodes.length === 0) {
                                comboplete_location_main.minChars = 0;
                                comboplete_location_main.evaluate();
                                
                            } else if (comboplete_location_main.ul.hasAttribute('hidden')) {
                                comboplete_location_main.open();
                            }
                        });

                        $("#location").parent('.awesomplete').parent('.awesomplete').removeClass('width-40');
                        $("#location").parent('.awesomplete').parent('.awesomplete').addClass('width-100');
                        $("#location").parent('.awesomplete').addClass('width-100');
                        
                        
                        //   $("#city").parents('.awesomplete').addClass('width-18');
                        //  $("#menuDeliveryLocationNewModalInput").parents('.awesomplete').addClass('width-40');
                        //  $(".menu-dlocation-input").parents('.awesomplete').addClass('width-100');

                    });

           


           }




            $.post(js_strings.site_url + 'users/get_recent_location', function(data) {
                data = eval('(' + data + ')');
                if(data!=null){
                    $('#recentLocNew').html(data.results);
                    $('#recentLocMob').html(data.results);
                        $('#recentLocMob').show();
                    
                    }
             });


</script>
<!--<div class="modal location-modal fade" id="menuDeliveryLocationNewModal" tabindex="-1" role="dialog" aria-labelledby="locationModal" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content modal-popup">
<div class="location-form">
<p class="theme-box-title-change-loc">Select Delivery Location <a href="#" id="closeIconModaleLoc" class="close-link" onClick="closeLocPopup()"><i class="fas fa-times-circle fa fa-times-circle-o"></i></a>
</p>
<div class="location-form-inner">
<form action="" method="post" class="has-validation-callback">
<div class="row">
<div class="col-sm-12 col-12" id="error-loction-new-modal" style="display:none;">
Location Not found
</div>
</div>
<div class="row">
<div class="col-sm-1 "></div>
<div class=" col-sm-3 pr-0">
<a class="btn main-search-mobile-head-popup city mt-0" data-toggle="modal" data-target="#page-load-city-modal-id">
<img class="flag" src="https://www.eateasy.ae/styles/img/ae.svg" width="20" alt="United Arab Emirates Flag">
Dubai
</a>
</div>
<div class="col-sm-7 pl-0">
<div class="right-inner-addon ">
<div class="awesomplete width-40 width-100">
<input id="menuDeliveryLocationNewModalInput" type="text" class="form-control menu-dlocation-input modal-new-location-suggest clearable" placeholder="Select Your Location" rel="" value="" autocomplete="off" aria-autocomplete="list">
<ul hidden=""></ul><span class="visually-hidden" role="status" aria-live="assertive" aria-relevant="additions"></span>
</div>
<i class="fa fa-search"></i>
</div>
</div>
<div class="col-sm-1 "></div>
</div>
<div class="row" id="locTopLocErr" style="display:none;">
<center class="error-color">Please select a location to proceed.</center>
</div>
<div class="row">
<div class="col-sm-1 "></div>
<div class="col-sm-10 ">
<input type="button" class="btn btn-primary" value="Continue" onClick="funGotoLoc()">
<div class="menu-search">
<div class="menu-current-location">
<a href="#" id="menuCurrentLocationNew">
<i class="fa fa-location-arrow" aria-hidden="true"></i>
Find restaurants nearby my location</a>
</div>
</div>
</div>
<div class="col-sm-1 "></div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>-->
<script>
            
function funSideDrawShow(){
    // console.log("#side-drawer");
    //         $("#side-drawer").show();
}

function setHomepageDeliveryRight(hashes_tab){
  //  var targetClass= $(event.target).attr("class");
    //$("#side-drawer").hide();
    //setHomepageDelivery(hashes_tab);
    console.log(document.URL);
   var newUrl= js_strings.site_url+'#'+hashes_tab;
   window.location.href=newUrl
    if(newUrl==document.URL){
        window.location.reload();
    }else{
        window.location.href=newUrl
    }

}


$(document).ready(function() {

///////////////////////////////////
    var haches = document.location.hash;
    var haches_splited = haches.split('=');
    var hashes_tab_seg1 = haches_splited[0];
    var hashes_tab = hashes_tab_seg1.replace('#!', "#");
        if (hashes_tab) {

            
           // var contentof = $(hashes_tab).html();
           
            setHomepageDelivery(hashes_tab);
           
        }

      

});
function setHomepageDeliveryMore(hashes_tab){
    $('.dropdownMenuHomeIconMore').dropdown("toggle"); //.trigger('click');
    setHomepageDelivery(hashes_tab);
}
function setHomeHiddenDelivery(hash,idd){

    var scrrenWidth = parseInt($(window).width()); 
    var totCh=8;
    if(scrrenWidth<576){
        totCh=2;
    }
    if(scrrenWidth > 575 && scrrenWidth <768){
        totCh=3;
    }
    if(scrrenWidth > 767  && scrrenWidth < 992){
        totCh=5;
    }
    if(scrrenWidth > 991  && scrrenWidth < 1200){
        totCh=7;
    }

    var newTotCh = totCh-1;

      var oldEle= $('#mainCategoryBoxHome > li:nth-child('+totCh+')');
      var oldEleId = oldEle.attr('id');
      
    $('#'+oldEleId+'-hide').show();
    $('#'+idd+'-hide').hide();

               // $('#mainCategoryBoxHome').prepend(  $("#")  );
                console.log(newTotCh,scrrenWidth,hash,idd,"#mainCategoryBoxHome",oldEleId);
                var htmEle =$('#'+idd);
                // $("#").remove();
                // $( htmEle ).insertAfter($('#mainCategoryBoxHome:nth-child(3)'));
                console.log(htmEle.innerHTML);
                $('#mainCategoryBoxHome > li:nth-child('+newTotCh+')').after(  htmEle ); 
                
               // $('#mainCategoryBoxHomeHide').prepend(  $("#-hide")  );
              

}
function setHomepageDelivery(hashes_tab){
  
    hashes_tab= hashes_tab.replace('#','');
    hashes_tab= hashes_tab.toLowerCase();
    console.log('incon', hashes_tab);
     
                var chk= "food";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeDeliveryTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeDeliveryTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeDeliveryTabLi').addClass('active');
                $('#homePageTabHeadText').html('Where do you want your purchase to be delivered?');
                $('#btnTextSpanHomeNearMe').html("Find restaurants nearby my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Food Delivery restaurants in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find restaurants nearby my location");

                $('#eateasyMainSearchHomeSub').html('Find Food Delivery restaurants in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/restaurants/search");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "grocery";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeGroceryTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeGroceryTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeGroceryTabLi').addClass('active');
                $('#homePageTabHeadText').html('Pick up your item from the store');
                $('#btnTextSpanHomeNearMe').html("Find Grocery near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Grocery in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Grocery near my location");

                $('#eateasyMainSearchHomeSub').html('Find Grocery in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=grocery");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "codes";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeCodesTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeCodesTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeCodesTabLi').addClass('active');
                $('#homePageTabHeadText').html('What is Codes (Dine in)? ');
                $('#btnTextSpanHomeNearMe').html("EatEasy wants to make your dine-in experience a little more special with Dine-in Code! You can opt from either buying codes, buy 1 get 1, or a wide array of discounts that you can redeem when you dine-in.");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('What is Codes (Dine in)? ');
                
                $('#eateasyMainSearchHomeDesc').html("EatEasy wants to make your dine-in experience a little more special with Dine-in Code! You can opt from either buying codes, buy 1 get 1, or a wide array of discounts that you can redeem when you dine-in.");

                $('#eateasyMainSearchHomeSub').html('What is Codes (Dine in)? ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/#codes");

                $('#arrReadMoreHome').text("#");

                  }  
                 
                var chk= "pharmacy";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homePharmacyTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homePharmacyTabLi');
                $(".main-category-button").removeClass('active');
                $('#homePharmacyTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Pharmacies in ');
                $('#btnTextSpanHomeNearMe').html("Find Pharmacies near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Pharmacies in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Pharmacies near my location");

                $('#eateasyMainSearchHomeSub').html('Find Pharmacies in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=pharmacy");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "cake";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeCakeTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeCakeTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeCakeTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Cakes Shop in ');
                $('#btnTextSpanHomeNearMe').html("Find Cakes Shop near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Cakes Shop in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Cakes Shop near my location");

                $('#eateasyMainSearchHomeSub').html('Find Cakes Shop in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=cake");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "flower";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeFlowerTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeFlowerTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeFlowerTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Flower Shop in ');
                $('#btnTextSpanHomeNearMe').html("Find Flower shop near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Flower Shop in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Flower shop near my location");

                $('#eateasyMainSearchHomeSub').html('Find Flower Shop in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=flower");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "butchery";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeButcheryTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeButcheryTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeButcheryTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Butchery Shops in ');
                $('#btnTextSpanHomeNearMe').html("Find Butchery shops near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Butchery Shops in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Butchery shops near my location");

                $('#eateasyMainSearchHomeSub').html('Find Butchery Shops in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=butchery");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "fruits";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeVegFruitTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeVegFruitTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeVegFruitTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Fruits & Vegetables in ');
                $('#btnTextSpanHomeNearMe').html("Find Fruits & Vegetables near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Fruits & Vegetables in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Fruits & Vegetables near my location");

                $('#eateasyMainSearchHomeSub').html('Find Fruits & Vegetables in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=fruit");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "gift";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeGiftTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeGiftTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeGiftTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Gift Shops in ');
                $('#btnTextSpanHomeNearMe').html("Find Gift Shops near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Gift Shops in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Gift Shops near my location");

                $('#eateasyMainSearchHomeSub').html('Find Gift Shops in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=gift");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "organic";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeOrganicTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeOrganicTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeOrganicTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Organic Stores in ');
                $('#btnTextSpanHomeNearMe').html("Find Organic Stores near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Organic Stores in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Organic Stores near my location");

                $('#eateasyMainSearchHomeSub').html('Find Organic Stores in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=organic");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "gourmet";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeGourmetTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeGourmetTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeGourmetTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Gourmet Stores in ');
                $('#btnTextSpanHomeNearMe').html("Find Gourmet Stores near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Gourmet Stores in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Gourmet Stores near my location");

                $('#eateasyMainSearchHomeSub').html('Find Gourmet Stores in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=gourmet");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "Pet";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homePetshopTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homePetshopTabLi');
                $(".main-category-button").removeClass('active');
                $('#homePetshopTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Pet Shops in ');
                $('#btnTextSpanHomeNearMe').html("Find Pet Shops near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Pet Shops in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Pet Shops near my location");

                $('#eateasyMainSearchHomeSub').html('Find Pet Shops in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=pet");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "specialty";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeSpecialityStoresTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeSpecialityStoresTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeSpecialityStoresTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Speciality Stores in ');
                $('#btnTextSpanHomeNearMe').html("Find Speciality Stores near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Speciality Stores in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Speciality Stores near my location");

                $('#eateasyMainSearchHomeSub').html('Find Speciality Stores in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=special");

                $('#arrReadMoreHome').text("");

                  }  
                 
                var chk= "deals";  chk=  chk.toLowerCase();
                //console.log(hashes_tab , chk,'homeDealsTabLi');
              if (hashes_tab === chk) {
                //console.log('incon', hashes_tab , chk,'homeDealsTabLi');
                $(".main-category-button").removeClass('active');
                $('#homeDealsTabLi').addClass('active');
                $('#homePageTabHeadText').html('Find Deals & Offers in ');
                $('#btnTextSpanHomeNearMe').html("Find Deals & Offers near my location");  
                $('#tyepSelectedTabHome').val(chk);
                
                $('#eateasyMainSearchHomeHeading').html('Find Deals & Offers in ');
                
                $('#eateasyMainSearchHomeDesc').html("Find Deals & Offers near my location");

                $('#eateasyMainSearchHomeSub').html('Find Deals & Offers in ');
                
                $('#arrReadMoreHome').attr("href", "https://www.eateasy.ae/dubai/grocery-delivery?refer=fdweb-groc&catType=deals");

                $('#arrReadMoreHome').text("");

                  }  
                             $('.codes-redirect-home-class').hide();
             $('#arrReadMoreHome').show();
       if(hashes_tab=='codes' || hashes_tab=='charity' || hashes_tab=='giftcard') {
           if(hashes_tab=='codes' ){
                $('.codes-redirect-home-class').show();
                $('#arrReadMoreHome').hide(); 
                $('#eateasyMainSearchHomeSub').hide();
           }
            $('#eateasyMainSearchHomeCategoryDiv').show();
           $('#eateasyMainSearchHomeDiv').hide();
       }
       else if(hashes_tab=='deals'){
        window.location.href='https://www.eateasy.ae/dubai/restaurants/search/offer-1';
       }
    //    else if(hashes_tab=='cake'){
    //     $('#preloader').show();
    //          $.get(js_strings.site_url+'home/getCusineCake',function(data){ 

    //             window.location.href=data;
    //             $('#preloader').hide();

    //         });
    //    }
       else{
        $('#eateasyMainSearchHomeCategoryDiv').hide();
           $('#eateasyMainSearchHomeDiv').show();
       
       }   

}
function gotoCakeShop(){
    $('#preloader').show();
             $.get(js_strings.site_url+'home/getCusineCake',function(data){ 

                window.location.href=data;
                $('#preloader').hide();

            });
}
function rightSidebarAccountTabTrigger(idd){
     var fetchClass="home"; 

    
    
    var myEle = document.getElementById(idd);
    console.log('rightSidebarAccountTabTrigger',idd);
    window.scrollTo(0,0);
    if(myEle){
        $('#'+idd).trigger('click');
        console.log('rightSidebarAccountTabTrigger found');
        if(! (idd=='homeCodesTabLi' && fetchClass=='home')){
            window.location.reload();
        }else{
            window.location.href="https://www.eateasy.ae/dubai/#codes";
            window.location.reload();
        }
        
    }

      
}

function launcherChatIDCLick(){
    console.log('support click');

    // $zopim(function() {
    //     $zopim.livechat.window.show();
    
    // });

    javascript:void($zopim.livechat.window.show())

    //zE(function() {zE.show();});

    // $zopim.livechat.window.show()

    //     $zopim(function() {
    //     $zopim.livechat.window.show();
    //   });
    // zE('webWidget', 'prefill', { name: { value: 'vikas', readOnly: true }});

        //$('#launcher').trigger('click');
}

function show_common_login_form_home(){
    $.post(js_strings.site_url+'users/login_form/',function(data){   		 
    		 data = eval('('+data+')');	       
	          $("#login-modal-id").html(data.results);
	          $("#login-modal-id").modal('show');	        
	         });    
} 

$(".mob-search-btn-close").click(function(){
    closeMobTopSerachPopup();
});   

function closeMobTopSerachPopup(){
        $("#mob-search").toggle();
        //$("#flot-search").show(); 
        window.scrollTo(0, 0);
}

function closeLocPopup(){
    
    $('#menuDeliveryLocationNewModal').modal('hide');
   
}

$('.top-search-tab-li').click(function (){
    var curr = this;
    var currId= $(this).attr('id'); console.log('currId',currId);
    $('.top-search-tab-li').each(function (){  $(this).removeClass('active');  });

    $(curr).addClass('active');
    
    $('#hiddenActiveTab').val(currId);

});

$(document).on('click', '#menuCurrentLocationNew', function() {
         
         $('#menu_delivery_location').modal('hide');
          $('#location-mobile-modal-id').modal('hide');

          $('#menuDeliveryLocationNewModal').modal('hide') ; 
                                            $('#closeIconModaleLoc').show();
         
       getMenuCurrentLocationNew();

});


function getMenuCurrentLocationNew() {
    
    if (navigator.geolocation) {      
       $('#preloader').show();
      
        navigator.geolocation.getCurrentPosition(function(position) {
            $('#preloader').hide();
            var latitude = position.coords.latitude;
            var longitutde = position.coords.longitude;
           
            //  alert("Found your location \nLat : "+position.coords.latitude+" \nLang :"+ position.coords.longitude);
            $.post(js_strings.site_url + 'home/getMenuCurrentLocation/' + latitude + '/' + longitutde+'/'+js_strings.lang_js, function(data) {
                //  alert(data);
                
                data = eval('(' + data + ')');
                if(data.error==1){
                   $('#preloader').hide();
                   alert_message(data.message);
                   return false;
                }
                var count = data.arrLocation.length;
                var city=1;
                var cityName='dubai';

               


                if (data.flgSingleLocation) {
                    if( data.city_id!=undefined && parseInt(data.city_id)>0){
                        city = data.city_id;
                    }
                    if( data.city_name!=undefined && $.trim(data.city_name)!=''){
                        cityName = data.city_name;
                    }
                     $.post(js_strings.site_url + 'order/set_delivery_loc/' +data.loc_id,{city:city,cityName:cityName} ,function(dataIn) {
                        dataIn = JSON.parse(dataIn);
                         if(dataIn.homeUrl!=undefined && $.trim(dataIn.homeUrl)!=''){
                             //alert(dataIn.homeUrl); 
                            window.location.href=dataIn.homeUrl;
                         }else{
                            window.location="";
                         }
                         
                       });
                  
                } else if (data.flgMultipleLocation) {
                    $('#current_location-modal-id').html(data.results);
                    $('#current_location-modal-id').modal('show');

                }
               

            });
            
            return false;
            
        },function(error){
           if(error.code=1){
               $('#preloader').hide();
               alert_message("You need to allow browser to give access to your location");
           }
        });
         
    } else {
        $('#preloader').hide();
        alert("Geolocation is not supported by this browser.");
    }
    
}

function showHomeMobDeliveryLocations(){
    getDeliveryLocations();
    $("#location-modal-id").modal('show'); 
    $("#mylocationmobile").focus();
}





$(document).on('click', '.homeInputLocation.clearable.x', function() {
  console.log('vk say test',$('.homeInputLocation').val());
  if($('.homeInputLocation').val()==''){
    setLocationAutoAfterClear(this);
    //Awesomplete.$('#location').evaluate();
  }
});


$(document).on('click', '#menuDeliveryLocationNewModalInput.clearable.x', function() {
  //console.log('vk say test menuDeliveryLocationNewModalInput',$('#menuDeliveryLocationNewModalInput').val());
  if($('#menuDeliveryLocationNewModalInput').val()==''){
    setLocationAutoAfterClear(this);
    //Awesomplete.$('#location').evaluate();
  }
});


var loginCart =false;
$(document).on('submit', '#loginCommonfrm', function() {
        
    $.post(js_strings.site_url + 'users/login/', $(this).serialize(), function(data) {
        data = eval('(' + data + ')');
        if (data.error == 0) {
            $("#login-modal-id").modal('hide');
            // if(loginCart==true){
            //    window.location = 'https://www.eateasy.ae/dubai//grocery/checkout';
            // }
            // else
            // { }
             //
             if( parseInt(data.tot_address)>0){
                location.reload();
             }else{
               window.location.href='https://www.eateasy.ae/dubai/users/myaccount?address=1'
             }
           
        } else {
            $("#login_error").show();
        }
    });

    return false;
});
  

</script>


<script src="https://www.eateasy.ae/styles/js/locationpicker.jquery.js?v=090820210001"></script>



<script>
    const toggleDrawer = (evt) => {
    evt.preventDefault();
    datavalue = evt.target.getAttribute('data-drawer');
    console.log (datavalue);
    document.querySelector(evt.target.getAttribute('data-drawer')).classList.toggle('is-open');
    }
    document.querySelectorAll('[data-drawer]').forEach(btn => btn.addEventListener('click', toggleDrawer));

    // $("[data-drawer]").on('click', function(e) {
    // e.preventDefault();
    // $($(this).data("drawer-up")).toggleClass("is-open");
    // });
    function funRemoveClass(idd,className,openClass=''){
       
        
        if(idd!='' && idd!=undefined ){
            $('#'+idd).removeClass(className);
            $('.errMsgMob').hide();
        }

        if(openClass!='' && openClass!=undefined ){
            $('#'+openClass).addClass(className);
            $('.errMsgMob').hide();
        }
    }
    

        $('.md-payment-type').click(function (){
            var checkbox = $(this).find('input[type=radio]');
            checkbox.prop("checked", !checkbox.prop("checked"));
        });
        // $('.delivery-address-list').click(function (){ alert('hii');
        //     var checkbox = $(this).find('input[type=radio]');
        //     checkbox.prop("checked", !checkbox.prop("checked"));
        // });

      function gotoMObPayCheckout(payType=''){
          var restIdMobCheckout= $('#restIdMobCheckout').val();
        funRemoveClass('Manage_Delivery_Address_Drawer','is-open','');
        funShowMobCart2(restIdMobCheckout,payType);
      }  
</script>

<script> 
       

          // <!-- Time Counter -->
          var timeLeft = 15;
          var elem = document.getElementById('Resend_OTP');
            function countdownOptMob() {
                if (timeLeft == -1) {
                 var currTimerIdMob = $('#currTimerIdMob').val();
                    clearTimeout(currTimerIdMob);
                    var innerHTML1 = '<a href="">Resend</a>';
                    $('#Resend_OTP').html(innerHTML1);
                } else {
                    var innerHTML1 = 'Resend OTP in ' + timeLeft + ' Sec';
                    $('#Resend_OTP').html(innerHTML1);
                    timeLeft--;
                }
            }

        $(document).on('click','.btn-address-mob',function (event){
            funRemoveClass('','is-open','Add_Delivery_Address_Drawer');
                //   $('.add-address').toggle('show');
                funAddressGeoCall();        
                    //&callback=initMapUserLocation
                    
                $('.addressMapMObADD').show();
                $('.addressAddDivMob').hide();
                    // $('#locationMapModal').modal({backdrop: 'static',keyboard: false});
                    $('#locationMapModalAddresId').val(0); 
                    $('#locationMapModalAddresIdMOb').val(0);
        });

        function setNewGeoAddresLocMOb(addressComponents) {
            var locationMapModalAddresId = $('#locationMapModalAddresId').val();
            if(locationMapModalAddresId>0){}else{
                //$('.add-address').show();
            }
            $('.addressAddDivMob').show();
            $('.addressMapMObADD').hide();
        }

        function sendOtpChangeMobileMOb(){

        }
    </script>






</div>
</div>










<style>
    /* body{width:610px;} */
    
</style>



  <?php require 'includes/_footer.php' ?>
 
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>





<script>

var lastScrollTop = 0;
window.addEventListener("scroll", function(){ 
   var st = window.pageYOffset || document.documentElement.scrollTop; 
   if (st > lastScrollTop){
      // downscroll code
   } else {
    header.classList.remove("header-sticky");
    //console.log ("up");
   }
   lastScrollTop = st <= 0 ? 0 : st; // For Mobile or negative scrolling
}, false);




$(window).click(function(event) {
    var curr = this;
    //|| !$(event.target).parents("#ee-autocomplete").length
   var targetClass= $(event.target).attr("class");
   var targetId= $(event.target).attr("id");

   if(targetClass=="modal-backdrop fade in"){
      var innerH = $('.modal-backdrop.fade.in').html();
      if(innerH =='' || innerH== undefined || innerH== null){
        $('.modal-backdrop.fade.in').remove();
        //$(curr).closest('div.modal-backdrop.fade.in').remove();
       // console.log('curr',  $(curr).html());
        console.log('.modal-backdrop fade in remove',innerH);
      }

   }


   console.log('targetClass',targetClass); 
   //console.log('targetId',targetId); 

    //    $(".form-control.focus-serach-web.clearable.x").click(function(){
    //                 var vals= $('#headerTopSearch').val();
    //                 console.log('form-control.focus-serach-web.clearable.x',vals)
    //                 selectSearchAutofill(vals); 
    //         })   

   if(targetClass =='form-control focus-serach-web clearable x'){
    var vals= $('#headerTopSearch').val();
                console.log('form-control.focus-serach-web.clearable.x',vals)
                selectSearchAutofill(vals); 
        // $('#headerTopSearch').val(''); //headerTopSearch
        // console.log('targetClass-valR',targetClass,targetId); 
        // $("#suggesstion-box-top-search").hide();
        // $("#suggesstion-box-top-search").html(''); //suggesstion-box-top-search
   }
   
   if( !(targetClass=="active top-search-tab-li-a" || targetClass=="top-search-tab-li-a" || targetId=="headerTopSearch" 
    || targetClass=="top-search-tab-li active" 
   )
   ){
    console.log('targetId hideinf'); 
    $("#suggesstion-box-top-search").hide();
    
   }
     //$(this).attr("class"),$(event).attr("class")
    //
});

var swiper = new Swiper('.swiper-container', {
            spaceBetween: 30,
            autoHeight: true, //enable auto height
            centeredSlides: true,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
}); 



$(document).on('click', '.form-control.focus-serach-web.clearable.x', function() {
 //$('#headerTopSearch').val('');
 //$('#triggerFodSrchClose').val(1);
 
 $("#panelFoodSerachTop").html(''); 
 $("#suggesstion-box-top-search").hide(); 

});
    

    $(document).ready(function(){
       
        setTopCart();

        //form-control focus-serach-web clearable x

        //  $(".form-control.focus-serach-web.clearable.x").click(function(){
        //         var vals= $('#headerTopSearch').val();
        //         console.log('form-control.focus-serach-web.clearable.x',vals)
        //         selectSearchAutofill(vals); 
        // })   


            // $("#headerTopSearch").click(function(){
            //     var vals= $('#headerTopSearch').val();
            //     selectSearchAutofill(vals); 
            // })   

            // var timeoutID = null;
            // $("#headerTopSearch").keyup(function(e){
            //         clearTimeout(timeoutID);
            //     //var vals= $('#headerTopSearch').val();
            //     timeoutID = setTimeout(() => selectSearchAutofill(e.target.value), 500);
            //     // selectSearchAutofill(vals); 
            // });

        ///////////////////////
        var typingTimer;                //timer identifier
        var doneTypingInterval = 1000;  //time in ms, 5 second for example
        var $input = $('#headerTopSearch');

        //on keyup, start the countdown
        $input.on('keyup', function () {
            clearTimeout(typingTimer);
            var valS= $('#headerTopSearch').val();
            if(valS=='' || valS==null || valS==undefined ){
                $("#panelFoodSerachTop").html(''); 
            } 
            $('#suggesstion-box-top-search').show(); 
            typingTimer = setTimeout(selectSearchAutofill, doneTypingInterval);
        });

        //on keydown, clear the countdown 
        $input.on('keydown', function () {
           clearTimeout(typingTimer);
        });

    });  


    function selectSearchAutofill(vals='') {
        $('#suggesstion-box-top-search').show(); 
        if(vals==''){
            vals =$('#headerTopSearch').val();
        }
        vals = vals.trim();
        if(vals!=''){
            $('#loaderFoodSerachTop').show(); 
            $('#panelFoodSerachTop').hide();

            // $('#loaderFoodSerachTop').removeAttr("style");
            // $('#panelFoodSerachTop').attr("style", "display:none");
            $("#suggesstion-box-top-search").show();
            // $('#loaderFoodSerachTop').removeClass('hideDivSearch');
            // $('#panelFoodSerachTop').addClass('hideDivSearch');

            $.ajax({
                type: "POST",
                url: "https://www.eateasy.ae/dubai/home/topSearch",
                data:'keyword='+vals,
                beforeSend: function(){
                   
                   // $("#suggesstion-box-top-search").css("background","#FFF url(LoaderIcon.gif) no-repeat 165px");
                   
                },
                success: function(data){
                    // $('#loaderFoodSerachTop').addClass('hideDivSearch');
                    // $('#panelFoodSerachTop').removeClass('hideDivSearch');
                    // $('#loaderFoodSerachTop').attr("style", "display:none");;
                    // $('#panelFoodSerachTop').removeAttr("style");
                    $("#suggesstion-box-top-search").show();
                    $('#panelFoodSerachTop').show();
                    $('#loaderFoodSerachTop').hide();
                    $("#panelFoodSerachTop").html(data);
                    $("#search-box").css("background","#FFF");
                    var currId = $('#hiddenActiveTab').val();
                    $('.top-search-tab-li').each(function (){  $(this).removeClass('active');  });
                    $('#acALL-liTab').addClass('active');
                },error: function (jqXHR, exception){
                    
                    $("#suggesstion-box-top-search").show();
                    $('#loaderFoodSerachTop').hide();
                    $('#panelFoodSerachTop').show();
                }
                });

        }else{
             $("#suggesstion-box-top-search").hide();
            // $("#suggesstion-box-top-search").html('');
        }            
    }    
    function setTopCart() {
        
        $.post(js_strings.site_url+'order/get_cart_food_count/',{type:'get-count'  } ,function(data){   
            console.log(data);
            data = eval('('+data+')');  
            $('#headerCartCountSpan').html(data.textTot);
                 $('#headerCartCount').val(data.total);//headerCartCountSpan
                

                 if(parseInt(data.total)>0){
                  $('#headerCartCountSpan').show();
                 }else{
                  $('#headerCartCountSpan').hide();
                 }
       });

    }

    function selectTopSerachItem(val,idd,type,code='') {
        console.log(val,idd,type);
        if(type==='locations'){
            var typeVal='food';
            $('#preloader').show();
                     $.post(js_strings.site_url+'home/setNewLocation/'+idd,{mainInput:val,type:typeVal  } ,function(data){   
                       // 
                       window.location.reload(); 
                       $('#preloader').hide();
                        
                     });
        }
        else if(type==='restaurants'|| type==='dish'){
            var newLoc="https://www.eateasy.ae/dubai/"+code;
            window.location.href=newLoc;
        }else if(type==='cuisines'){
            val= val.replace(' ','-');
            var newLoc="https://www.eateasy.ae/dubai/restaurants/search/cuisinecode-"+val+'-'+idd;
            window.location.href=newLoc;
        }
        else{
            var mainA = ['cuisines','services','facilities']; 
            var mainCode = ['cuisinecode','services','facilities'];
            for(var i=0;i<mainA.length;i++){
                if(type==mainA[i]){
                    $('#hideFormRest'+type).val(idd);
                }
            }
            
            $('#hideFormRestSearch').submit();
        }
        $("#headerTopSearch").val(val);
        //$("#suggesstion-box-top-search").hide();
    }
</script>




<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=dc746457-02a6-41da-9de5-4493849d2471"> </script>

<script type="text/javascript">
    
    
    /*
 setTimeout(function(){   
    window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//v2.zopim.com/?6vPc2T2iI2ZTR3LkkrVG6fFFX3uOeqJl';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script'); */
  // },1500);
    </script>


<script>
setTimeout(function(){
!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);
},s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='//static.ads-twitter.com/uwt.js',
a=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');
// Insert Twitter Pixel ID and Standard Event data below
twq('init','ny4ze');
twq('track','PageView');
},1500);
</script>


<script>
setTimeout(function(){
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '1467950800138592');
     
  fbq('track', 'PageView');
  },1500);
</script>
  <script>
 function disableClick(){
 document.onclick=function(event){
 if (event.button == 2) {
 alert('Right Click Message');
 return false;
 }
 }
 }
 </script>
 <script>
var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude + 
  "<br>Longitude: " + position.coords.longitude;
}
</script>


<script>

let tabs = document.querySelectorAll('.tab');
        let content = document.querySelectorAll('.content-item');
        for (let i = 0; i < tabs.length; i++) {            
            tabs[i].addEventListener('click', () => tabClick(i));
        }

        function tabClick(currentTab) {
            removeActive();
            tabs[currentTab].classList.add('active');
            content[currentTab].classList.add('active');
            console.log(currentTab);
        }

        function removeActive() {
            for (let i = 0; i < tabs.length; i++) {
                tabs[i].classList.remove('active');
                content[i].classList.remove('active');
            }
        }

</script>
 
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
</body>
</html>