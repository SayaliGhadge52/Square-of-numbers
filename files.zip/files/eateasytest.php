<section class="eateasy-home-banner no-banner">
</section>

<section class="eateasy-location-search bg-white">
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="location-search-box-outer">
<ul class="main-category-box" id="mainCategoryBoxHome">
<li class="main-category-button active 1" id="homeDeliveryTabLi" onClick="setHomepageDelivery('food')">
<a href="#food">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/Delivery.png" alt=""></div>
<div class="category-name">Food Delivery</div>
</a>
</li>
<li class="main-category-button  2" id="homeGroceryTabLi" onClick="setHomepageDelivery('grocery')">
<a href="#grocery">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/supermarkets.png" alt=""></div>
<div class="category-name">Grocery Delivery</div>
</a>
</li>
<li class="main-category-button  3" id="homeCodesTabLi" onClick="setHomepageDelivery('codes')">
<a href="#codes">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/dinein.png" alt=""></div>
<div class="category-name">Codes (Dine in)</div>
</a>
</li>
<li class="main-category-button  4" id="homePharmacyTabLi" onClick="setHomepageDelivery('pharmacy')">
<a href="#pharmacy">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/Pharmacy.png" alt=""></div>
<div class="category-name">Pharmacies</div>
</a>
</li>
<li class="main-category-button  5" id="homeCakeTabLi" onClick="setHomepageDelivery('cake')">
<a href="#cake">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/cake-shop.png" alt=""></div>
<div class="category-name">Cake Shop</div>
</a>
</li>
<li class="main-category-button  6" id="homeFlowerTabLi" onClick="setHomepageDelivery('flower')">
<a href="#flower">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/Cake-Flower-Delivery.png" alt=""></div>
<div class="category-name">Flower Shop</div>
</a>
</li>
<li class="main-category-button  7" id="homeButcheryTabLi" onClick="setHomepageDelivery('butchery')">
<a href="#butchery">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/ButcheryShops.png" alt=""></div>
<div class="category-name">Butchery Shops</div>
</a>
</li>
<li class="main-category-button  8" id="homeVegFruitTabLi" onClick="setHomepageDelivery('fruits')">
<a href="#fruits">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/Fruits.png" alt=""></div>
<div class="category-name">Fruits & Vegetables</div>
</a>
</li>
<li class="main-category-button  9" id="homeGiftTabLi" onClick="setHomepageDelivery('gift')">
<a href="#gift">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/GiftShop.png" alt=""></div>
<div class="category-name">Gift Shops</div>
</a>
</li>
<li class="main-category-button  10" id="homeOrganicTabLi" onClick="setHomepageDelivery('organic')">
<a href="#organic">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/OrganicStores.png" alt=""></div>
<div class="category-name">Organic Stores</div>
</a>
</li>
<li class="main-category-button  11" id="homeGourmetTabLi" onClick="setHomepageDelivery('gourmet')">
<a href="#gourmet">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/GourmetStores.png" alt=""></div>
<div class="category-name">Gourmet Stores</div>
</a>
</li>
<li class="main-category-button  12" id="homePetshopTabLi" onClick="setHomepageDelivery('Pet')">
<a href="#Pet">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/PetShops.png" alt=""></div>
<div class="category-name">Pet Shops</div>
</a>
</li>
<li class="main-category-button  13" id="homeSpecialityStoresTabLi" onClick="setHomepageDelivery('specialty')">
<a href="#specialty">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/home/specialityStores.png" alt=""></div>
<div class="category-name">Speciality Stores</div>
</a>
</li>
<li class="main-category-button  14" id="homeDealsTabLi" onClick="setHomepageDelivery('deals')">
<a href="#deals">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/DealsOffers.png" alt=""></div>
<div class="category-name">Deals & Offers</div>
</a>
</li>
<div class="dropdown category-more">
<li class="main-category-button dropdownMenuHomeIconMore" id="dropdownMenu1" data-toggle="dropdown">
<a href="">
<div class="category-icon"><img src="https://www.eateasy.ae/styles/img/more.png" alt=""></div>
<div class="category-name">More</div>
</a>
</li>
<ul class="dropdown-menu pull-right" role="menu" aria-labelledby="dropdownMenu1" id="mainCategoryBoxHomeHide">
<li class="hidden-category 1" id="homeDeliveryTabLi-hide" onClick="setHomeHiddenDelivery('food','homeDeliveryTabLi')">
<a role="menuitem" tabindex="-1" href="#food" onClick="setHomepageDeliveryMore('food')">
Food Delivery </a>
</li>
<li class="hidden-category 2" id="homeGroceryTabLi-hide" onClick="setHomeHiddenDelivery('grocery','homeGroceryTabLi')">
<a role="menuitem" tabindex="-1" href="#grocery" onClick="setHomepageDeliveryMore('grocery')">
Grocery Delivery </a>
</li>
<li class="hidden-category 3" id="homeCodesTabLi-hide" onClick="setHomeHiddenDelivery('codes','homeCodesTabLi')">
<a role="menuitem" tabindex="-1" href="#codes" onClick="setHomepageDeliveryMore('codes')">
Codes (Dine in) </a>
</li>
<li class="hidden-category 4" id="homePharmacyTabLi-hide" onClick="setHomeHiddenDelivery('pharmacy','homePharmacyTabLi')">
<a role="menuitem" tabindex="-1" href="#pharmacy" onClick="setHomepageDeliveryMore('pharmacy')">
Pharmacies </a>
</li>
<li class="hidden-category 5" id="homeCakeTabLi-hide" onClick="setHomeHiddenDelivery('cake','homeCakeTabLi')">
<a role="menuitem" tabindex="-1" href="#cake" onClick="setHomepageDeliveryMore('cake')">
Cake Shop </a>
</li>
<li class="hidden-category 6" id="homeFlowerTabLi-hide" onClick="setHomeHiddenDelivery('flower','homeFlowerTabLi')">
<a role="menuitem" tabindex="-1" href="#flower" onClick="setHomepageDeliveryMore('flower')">
Flower Shop </a>
</li>
<li class="hidden-category 7" id="homeButcheryTabLi-hide" onClick="setHomeHiddenDelivery('butchery','homeButcheryTabLi')">
<a role="menuitem" tabindex="-1" href="#butchery" onClick="setHomepageDeliveryMore('butchery')">
Butchery Shops </a>
</li>
<li class="hidden-category 8" id="homeVegFruitTabLi-hide" onClick="setHomeHiddenDelivery('fruits','homeVegFruitTabLi')">
<a role="menuitem" tabindex="-1" href="#fruits" onClick="setHomepageDeliveryMore('fruits')">
Fruits & Vegetables </a>
</li>
<li class="hidden-category 9" id="homeGiftTabLi-hide" onClick="setHomeHiddenDelivery('gift','homeGiftTabLi')">
<a role="menuitem" tabindex="-1" href="#gift" onClick="setHomepageDeliveryMore('gift')">
Gift Shops </a>
</li>
<li class="hidden-category 10" id="homeOrganicTabLi-hide" onClick="setHomeHiddenDelivery('organic','homeOrganicTabLi')">
<a role="menuitem" tabindex="-1" href="#organic" onClick="setHomepageDeliveryMore('organic')">
Organic Stores </a>
</li>
<li class="hidden-category 11" id="homeGourmetTabLi-hide" onClick="setHomeHiddenDelivery('gourmet','homeGourmetTabLi')">
<a role="menuitem" tabindex="-1" href="#gourmet" onClick="setHomepageDeliveryMore('gourmet')">
Gourmet Stores </a>
</li>
<li class="hidden-category 12" id="homePetshopTabLi-hide" onClick="setHomeHiddenDelivery('Pet','homePetshopTabLi')">
<a role="menuitem" tabindex="-1" href="#Pet" onClick="setHomepageDeliveryMore('Pet')">
Pet Shops </a>
</li>
<li class="hidden-category 13" id="homeSpecialityStoresTabLi-hide" onClick="setHomeHiddenDelivery('specialty','homeSpecialityStoresTabLi')">
<a role="menuitem" tabindex="-1" href="#specialty" onClick="setHomepageDeliveryMore('specialty')">
Speciality Stores </a>
</li>
<li class="hidden-category 14" id="homeDealsTabLi-hide" onClick="setHomeHiddenDelivery('deals','homeDealsTabLi')">
<a role="menuitem" tabindex="-1" href="#deals" onClick="setHomepageDeliveryMore('deals')">
Deals & Offers </a>
</li>

</ul>
</div>
</ul>
<div class="clear"></div>
<div class="col-md-12 col-lg-8 col-lg-offset-2">
<div class="eateasy-main-search" id="eateasyMainSearchHomeDiv">
<h1><span id="homePageTabHeadText">Find food delivery restaurants in</span> Dubai</h1>
<form id="frmHomeSearchNew" action="https://www.eateasy.ae/dubai/restaurants/search/ " class="has-validation-callback">
<input type="hidden" id="tyepSelectedTabHome" name="tyepSelectedTabHome" value="food" />
<div class="input-group">
<a class="btn main-search-mobile city" data-toggle="modal" data-target="#page-load-city-modal-id">
<img class="flag" src="https://www.eateasy.ae/styles/img/ae.svg" width="20" alt="United Arab Emirates Flag">
Dubai
</a>
<div class="awesomplete search-bar width-100">
<input id="location" placeholder="Enter your location" rel='0' value="" val="" type="text" class="search-field location modal-new-location-suggest homeInputLocation clearable 
                                     " autocomplete="off" aria-autocomplete="list">
<ul hidden=""></ul>
<span class="visually-hidden" role="status" aria-live="assertive" aria-relevant="additions"></span>
</div>
<input type="hidden" name="location" id="type">
<div class="main-search-mobile location" onClick="showHomeMobDeliveryLocations()"></div>

<input type="button" class="search-button btn-home-search" onClick="funGotoLocHome()" value="Search">
</div>
</form>
<div class="current-location home-curr-loc-div">
<a href="#" id="currentLocationNew">
<i class="fa fa-location-arrow" aria-hidden="true"></i>
<span id="btnTextSpanHomeNearMe" onClick="getLocationNew()"> Find restaurants nearby my location</span>
</a>
</div>
</div>
<div class="eateasy-main-category-details" id="eateasyMainSearchHomeCategoryDiv" style="display:none;">
<h4 class="eec-red" id="eateasyMainSearchHomeHeading">What is Codes (Dine in)?</h4>
<p id="eateasyMainSearchHomeDesc">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it</p>
<a id="arrReadMoreHome" href="#" class="btn eeb-primary">Read More</a>
<div class="codes-redirect-home-class" style="display:none;">
<h4 id="eateasyMainSearchHomeSub">Codes (Dine In) is currently available for our App users. </h4>
<div class="app-store">
<a target="_blank" href="https://apps.apple.com/us/app/id734231600?ls=1">
<img src="https://www.eateasy.ae/styles/img/apple-store.png" alt="Play Store">
</a>
<a target="_blank" href="https://play.google.com/store/apps/details?id=com.eateasily.androidapp">
<img src="https://www.eateasy.ae/styles/img/google-play.png" alt="App Store">
</a>
</div>
</div>
</div>
<div class="clearfix"></div>
</div>
</div>
</div>
</div>
</div>
</section>