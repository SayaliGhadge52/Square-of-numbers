<?php 
session_start();	
include 'includes/_dbconnect.php';
 
if(!isset($_SESSION['userId'])){
	echo "<script>alert('You Need to be Login!');
                    window.history.back(1);
                    </script>";
} else {
		 $userId = $_SESSION['userId'];
		 $product_id=$_GET['id'];
		 
		 $mysql = "SELECT * FROM `wishlist` WHERE  userId = $userId AND product_id = $product_id" ;
         $myresult = mysqli_query($conn, $mysql);
		 if(mysqli_num_rows($myresult) == 1 ){
			echo "<script>alert('Product Already Exist in wishlist.');
                    window.history.back(1);
                    </script>";
			//header('location:show.php');
			
		 } else {
			$sql = "INSERT INTO `wishlist` (`userId`, `product_id`) VALUES ('$userId', '$product_id')";
	     
		    if(mysqli_query($conn, $sql)){
			 echo "<script>alert('Product Added in wishlist.');
                    window.history.back(1);
                    </script>";
		 } 
}
}

?>
