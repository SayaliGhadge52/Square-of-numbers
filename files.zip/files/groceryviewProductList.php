<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title id="title">Category</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
    <style>
	
	
	body {
    font-family: "open_sansregular" !important;
}
	
	
	
    .jumbotron {
        padding: 2rem 1rem;
    }
    #cont {
        min-height : 570px;
    }
	.cart-count {
  
  color: #red important;
  
}
	.cart-item {
      position:absolute;
      height:24px;
      width:24px;
      top:-10px;
      right:-10px;
      &:before {
        content:'1';
        display:block;
        line-height:24px;
        height:24px;
        width:24px;
        font-size:12px;
        font-weight:600;
        background:#2bd156;
        color:white;
        border-radius:20px;
        text-align:center;
      }
    }

/*-------sidebar----------*/
.l-navbar ul{
	margin-left: 10px;
}
.l-navbar ul li{
	list-style-type: none;
	font-weight: bold;
	margin-top: 4px;
	margin-bottom: 4px;
	cursor: pointer;
	padding: 0 30px 5px 5px;
	border-bottom:  solid #fff;
    overflow:hidden;	
}
.l-navbar ul li a:hover{
	color: orange;
	
}
.l-navbar ul li a{
	color: black;
	
}
/*-------sidebar end----------*/
/*-----------Wishlist----------------*/
.card-body .wishlist{
	float: right;
	z-index: 1;
}
/*-----------Wishlist- end-----------*/
    </style>
</head>
<body>
    <?php include 'includes/_dbconnect.php';?>
    <?php require 'includes/_nav.php' ?>

    <div>&nbsp;
        <a href="index.php" class="active text-dark">
        <i class="fas fa-qrcode"></i>
            <span>All Category</span>
        </a>
    </div>

    <?php
        $id = $_GET['catid'];
        $sql = "SELECT * FROM `categories` WHERE categorieId = $id";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result)){
            $catname = $row['categorieName'];
            $catdesc = $row['categorieDesc'];
        }
    ?>
  
    <!-- Product container starts here -->
    
        <div class="col-lg-4 text-center bg-light my-3" style="margin:auto;border-bottom: 2px #426047;color:#426047 !important">     
            <h2 class="text-center"><span id="catTitle">Items</span></h2>
        </div>
		<div class="l-navbar" id="nav-bar">
        <nav class="nav">
			<ul>
                <div class="nav__list">
                    <li style="color:#426047; text-decoration:underline solid 2px #000000;"><a href="groceryindex.php" class="nav__link">Grocery Categories</a></li>
                    <li>
					<?php
					    $sql = "SELECT categorieName, categorieId FROM `grocery_category`"; 
                        $result = mysqli_query($conn, $sql);
                        while($row = mysqli_fetch_assoc($result)){
                        echo '<li><a class="nav__link" href="groceryviewProductList.php?catid=' .$row['categorieId']. '">' .$row['categorieName']. '</a></li>';
                        }
					?>
					</li>
					
					<!--<li><a href="groceryviewProductList.php?catid=1" class="nav__link">Tea & Coffee</a></li> 
                    <li><a href="groceryviewProductList.php?catid=2" class="nav__link">Noodles & Pasta</a></li>
                    <li><a href="groceryviewProductList.php?catid=3" class="nav__link">Rice & Rice product</a></li>
					<li><a href="groceryviewProductList.php?catid=4" class="nav__link">For Cooking</a></li>
					<li><a href="groceryviewProductList.php?catid=5" class="nav__link">GF Breads & Pastries</a></li>
					<li><a href="groceryviewProductList.php?catid=6" class="nav__link">Beverages</a></li>
					<li><a href="groceryviewProductList.php?catid=7" class="nav__link">Baby Foods</a></li>
					<li><a href="groceryviewProductList.php?catid=8" class="nav__link">Seasoning</a></li>-->
                </div>
			</ul>
	<div class="container my-3" id="cont">
        <div class="row">
        <?php
            $id = $_GET['catid'];
            $sql = "SELECT * FROM `grocery` WHERE productCategorieId = $id";
            $result = mysqli_query($conn, $sql);
            $noResult = true;
            while($row = mysqli_fetch_assoc($result)){
                $noResult = false;
                $productId = $row['productId'];
                $productName = $row['productName'];
                $productPrice = $row['productPrice'];
                $productDesc = $row['productDesc'];
            
                echo '<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="card" style="width: 18rem;">
                            <img src="img/grocery/groceryitem-'.$productId. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                            <div class="card-body">
                                <h5 class="card-title">' . substr($productName, 0, 15). '...</h5>
                                <h5 style="color: #333"><b>AED '.$productPrice.'.00</b><span class="wishlist"><a href="groc_wishlist.php?id=' .$productId. '"><i class=" fa fa-heart" style="color: grey"></i></a></span></h5>
                                <p class="card-text">' . substr($productDesc, 0, 20). '...</p>   
                                <div class="row justify-content-center">';
                                if($loggedin){
                                    $quaSql = "SELECT `itemQuantity` FROM `viewcart` WHERE productId = '$productId' AND `userId`='$userId'";
                                    $quaresult = mysqli_query($conn, $quaSql);
                                    $quaExistRows = mysqli_num_rows($quaresult);
									while($quaExistRows1=mysqli_fetch_array($quaresult)){
									$Quantity=$quaExistRows1['itemQuantity'];
									
									echo '<form id="frm' . $productId . '">
                                                    <input type="hidden" name="productId" value="' . $productId . '">
                                                    <input type="number" name="quantity" value="' . $Quantity . '" class="text-center" onchange="updateCart(' . $productId . ')" onkeyup="return false" style="width:50px" ,border-color:#d87944 !important; min=1 oninput="check(this)" onClick="this.select();">
                                                </form>';
									}
                                    if($quaExistRows == 0) {
                                        echo '<form action="includes/_manageCart.php" method="POST">
                                              <input type="hidden" name="itemId" value="'.$productId. '">
                                              <button type="submit" name="addToCart" class="btn btn-primary mx-2" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>';
                                    }else {
                                        echo '<a href="viewCart.php"><button class="btn btn-primary mx-2" style="background-color:#ffff !important;border:none !important;"><i class="fas fa-shopping-cart" style="font-size:30px;color:#d87944";></i> 
<span style="color:#426047!important;position:relative;height:24px;width:24px;top:-25px; right:10px;font-weight:bold;"> '.$Quantity.'</span></button></a>' ;
										
                                    }
                                }
                                else{
                                    echo '<button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>';
                                }
                            echo '</form>                            
                                <a href="groceryviewProduct.php?productid=' . $productId . '" class="mx-2"><button class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">Quick View</button></a> 
                                </div>
                            </div>
                        </div>
                    </div>';
            }
            if($noResult) {
                echo '<div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <p class="display-4">Sorry In this category No items available.</p>
                        <p class="lead"> We will update Soon.</p>
                    </div>
                </div> ';
            }
            ?>
        </div>
    </div>
</nav>
</div>

    <?php require 'includes/_footer.php' ?>
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
    <script> 
        document.getElementById("title").innerHTML = "<?php echo $catname; ?>"; 
        document.getElementById("catTitle").innerHTML = "<?php echo $catname; ?>"; 
    </script> 
	<script>
        function check(input) {
            if (input.value <= 0) {
                input.value = 1;
            }
        }
        function updateCart(id) {
            $.ajax({
                url: 'includes/_manageCart.php',
                type: 'POST',
                data:$("#frm"+id).serialize(),
                success:function(res) {
                    location.reload();
                } 
            })
        }
    </script>
	
	
	
	
	
	
	
</body>
</html>