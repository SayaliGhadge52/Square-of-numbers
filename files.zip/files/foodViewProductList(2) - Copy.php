<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Home</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
  
	
	
	
	
	<style>
	body {
    font-family: "open_sansregular" !important;
}	
	
		.showcase-area {
  height: 50vh;
  background: linear-gradient(
      rgba(240, 240, 240, 0.144),
      rgba(255, 255, 255, 0.336)
    ),
    url("img/banner.png");
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.showcase-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  font-size: 1.6rem;

}

.main-title {
  text-transform: uppercase;
  margin-top: 1.5em;
}

.card-body .wishlist{
	float: right;
	z-index: 1;
}

/*-------side-menu-----------*/

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}
 
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
/*-----end------*/


	</style>
	
	
	
  </head>
<body>
  <?php include 'includes/_dbconnect.php';?>
  <?php require 'includes/_nav.php' ?>
  
  <!-- Category container starts here -->
  
  
  

  

  <!-- page wrapper starts here -->
  <div class="body-content outer-top-xs">
  
  
  <section class="showcase-area" id="showcase">
      <div class="showcase-container">
        <h1 class="main-title" id="home"></h1>
        <p></p>
       
      </div>
    </section>

  

   
    <div class="col-lg-2 text-center bg-light my-3" style="margin:auto;border-bottom: 2px; color:#426047 !important;">     
      <h2 class="text-center">Menu</h2>
	 
    </div>
    <div class="sidebar">
            <?php
		            $sql = "SELECT categorieName, categorieId FROM `categories`"; 
                    $result = mysqli_query($conn, $sql);
                    while($row = mysqli_fetch_assoc($result)){
                    echo '<li><a class="nav__link" href="viewProductList.php?catid=' .$row['categorieId']. '">' .$row['categorieName']. '</a></li>';
                    }
			?>
    </div>
            
    <div class="container my-3" id="cont">
    <div class="row">

         <?php 
                    $sql = "SELECT * FROM `product`";  
                    $result = mysqli_query($conn, $sql);
                    while($row = mysqli_fetch_assoc($result)){
                    $id = $row['productId'];
                    $cat = $row['productName'];
                    $desc = $row['productDesc'];
		            $productPrice = $row['productPrice'];
                    echo '<div class="col-xs-3 col-sm-3 col-md-3">
                    <div class="card" style="width: 18rem;">
                    <img src="img/menu-'.$id. '.jpg" class="card-img-top" alt="image for this product" width="249px" height="270px">
                    <div class="card-body">
                      <h5 class="card-title"><a style="color:#d87944 !important;" href="viewProductList.php?catid=' . $id . '">' . substr($cat, 0, 15). '...</a></h5>
                      <p class="card-text">' . substr($desc, 0, 20). '... </p>
                      <h5 style="color: #333"><b>AED '.$productPrice.'.00</b><span class="wishlist"><a href="wishlist.php?id=' .$id. '"><i class=" fa fa-heart" style="color: grey"></i></a></span></h5>
				   <button class="btn btn-primary mx-2" data-toggle="modal" data-target="#loginModal" style="background-color:#426047 !important;border-color:#426047 !important;">Add to Cart</button>
				   <a href="viewProduct.php?productid=' . $id . '" class="mx-2"><button class="btn btn-primary" style="background-color:#426047 !important;border-color:#426047 !important;">Quick View</button></a>
                    </div>
                    </div>
                    </div>';
                }
        ?>
    </div>
    </div>

 
  <!-- page wrapper starts here -->
    <?php require 'includes/_footer.php' ?>
	
      <script>
	  function openmenu(){
		  document.getElementById("side-menu").style.display="block";
		  document.getElementById("menu-btn").style.display="none";
		  document.getElementById("close-btn").style.display="block";
	  }
	  function closemenu(){
		  document.getElementById("side-menu").style.display="none";
		  document.getElementById("menu-btn").style.display="block";
		  document.getElementById("close-btn").style.display="none";
	  }
	  
	 

	</script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
	
	<?php require 'includes/_footer.php' ?>
</body>
</html>