<?php
session_start();
include 'includes/_dbconnect.php';
if(!isset($_SESSION['userId'])){
    
header('location:index.php');
}else{
 $product_id = $_GET['product_id']; 
 $userId = $_GET['userId'];
 

    $delWishlist = "DELETE FROM wishlist WHERE product_id='$product_id' AND userId='$userId'";   
	if(mysqli_query($conn, $delWishlist)){
        header('location:show-wishlist.php');

    }

}

?>