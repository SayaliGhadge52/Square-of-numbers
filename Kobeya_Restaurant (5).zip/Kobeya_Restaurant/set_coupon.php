<?php
include 'includes/_dbconnect.php';
include 'includes/function.php';

$coupon_code=get_safe_value($_POST['coupon_code']);
$res=mysqli_query($conn,"select * from coupon_code where coupon_code='$coupon_code'");
//$check=(!$res)?mysqli_num_rows($res):0;
if(mysqli_num_rows($res)>0){
    $row=mysqli_fetch_assoc($res);	
	$expired_on=strtotime($row['expired_on']);
	$cur_time=strtotime(date('Y-m-d'));
	
	$arr=array('status'=>'success','msg'=>'coupon code apply successfully.','final_value'=>$row['coupon_value']);
    if($cur_time>$expired_on){
			$arr=array('status'=>'error','msg'=>'Coupon code expired');	
		}
}
else{
	$arr=array('status'=>'error','msg'=>'Please enter valid coupon code.');
} 

echo json_encode($arr);

?>