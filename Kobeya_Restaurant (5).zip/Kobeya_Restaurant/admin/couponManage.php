<div class="container-fluid" style="margin-top:98px">
    <div class="col-lg-12">
        <div class="row">
            <!-- FORM Panel -->
            <div class="col-md-4">
                <form action="includes/_couponManage.php" method="post" enctype="multipart/form-data">
                    <div class="card">
                        <div class="card-header" style="color:#FFFFFF; background-color:#426047 !important;">
                            Add Discount
                        </div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="control-label">Coupon Code: </label>
                                <input type="text" class="form-control" name="code" required>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Coupon Type: </label>
                                <input type="text" class="form-control" name="type" required>
                            </div> 
							<div class="form-group">
                                <label class="control-label">Coupon Amount: </label>
                                <input type="number" class="form-control" name="value" required>
                            </div>
                            <!--<div class="form-group">
                                <label class="control-label">Cart Min Amount: </label>
                                <input type="number" class="form-control" name="minvalue" required>
                            </div>-->
							<div class="form-group">
                                <label class="control-label">Expired On: </label>
                                <input type="date" class="form-control" name="exp_on" required>
                            </div> 
                        </div>  
                        <div class="card-footer">
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" name="createCoupon" class="btn btn-sm btn-primary col-sm-3 offset-md-4" style="background-color:#426047 !important;"> Create </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- FORM Panel -->
    
            <!-- Table Panel -->
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-body">
                    <table class="table table-bordered table-hover mb-0">
                        <thead style="color:#FFFFFF; background-color:#426047;">
                        <tr>
                            <th class="text-center" style="width:5%;">Id</th>
                            <th class="text-center" style="width:7%;">Coupon Code</th>
                            <th class="text-center" style="width:7%;">Coupon Type</th>
							<th class="text-center" style="width:7%;">Coupon Amount</th>
							<!--<th class="text-center" style="width:7%;">Cart Min Amount</th>-->
							<th class="text-center" style="width:9%;">Expired On</th>
                            <th class="text-center" style="width:10%;">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php 
                            $sql = "SELECT * FROM `coupon_code`"; 
                            $result = mysqli_query($conn, $sql);
                            while($row = mysqli_fetch_assoc($result)){
                                $id = $row['id'];
                                $c_code = $row['coupon_code'];
                                $c_type = $row['coupon_type'];
								$c_value = $row['coupon_value'];
								$cartMin = $row['cart_min_value'];
								$exp_on = $row['expired_on'];

                                echo '<tr>
                                        <td class="text-center"><b>' .$id. '</b></td>
                                        <td class="text-center"><b>' .$c_code. '</b></td>
                                        <td class="text-center"><b>' .$c_type. '</b></td>
										<td class="text-center"><b>' .$c_value. '</b></td>
										<!--<td class="text-center"><b>' .$cartMin. '</b></td>-->
										<td class="text-center"><b>' .$exp_on. '</b></td>
                                        <td class="text-center">
                                            <div class="row mx-auto" style="width:112px">
                                            <button class="btn btn-sm btn-primary edit_coupon" style="background-color: #426047"  type="button" data-toggle="modal" data-target="#updateCat' .$id. '"><i class="fas fa-edit"></i></button>
                                            <form action="includes/_couponManage.php" method="POST">
                                                <button name="removeCoupon" class="btn btn-sm btn-danger" style="margin-left:9px;"><i class="fas fa-trash"></i></button>
                                                <input type="hidden" name="id" value="'.$id. '">
                                            </form></div>
                                        </td>
                                    </tr>';
                            }
                        ?> 
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <!-- Table Panel -->
        </div>
    </div>	    
</div>


<?php 
    $couponsql = "SELECT * FROM `coupon_code`";
    $couponResult = mysqli_query($conn, $couponsql);
    while($couponRow = mysqli_fetch_assoc($couponResult)){
        $id = $couponRow['id'];
        $c_code = $couponRow['coupon_code'];
        $c_type = $couponRow['coupon_type'];
		$c_value = $couponRow['coupon_value'];
		$cartMin = $couponRow['cart_min_value'];
		$exp_on = $couponRow['expired_on'];
?>


<!-- Modal -->
<div class="modal fade" id="updateCat<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="updateCoupon<?php echo $id; ?>" aria-hidden="true" style="width: -webkit-fill-available;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #426047 !important;">
        <h5 class="modal-title" id="updateCoupon<?php echo $id; ?>">Coupon Id: <b><?php echo $id; ?></b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="includes/_couponManage.php" method="post">
            <div class="text-left my-2">
                <b><label for="code">Coupon Code</label></b>
                <input class="form-control" id="code" name="code" value="<?php echo $c_code; ?>" type="text" required>
            </div>
            <div class="text-left my-2">
                <b><label for="type">Coupon Type</label></b>
                <input class="form-control" id="type" name="type" value="<?php echo $c_type; ?>" type="text" required>
            </div>
			<div class="text-left my-2">
                <b><label for="value">Coupon Amount</label></b>
                <input class="form-control" id="value" name="value" value="<?php echo $c_value; ?>" type="text" required>
            </div>
			<!--<div class="text-left my-2">
                <b><label for="minvalue">Cart Min Amount</label></b>
                <input class="form-control" id="minvalue" name="minvalue" value="<?php echo $cartMin; ?>" type="text" required>
            </div>-->
			<div class="text-left my-2">
                <b><label for="exp_on">Expired On</label></b>
                <input class="form-control" id="exp_on" name="exp_on" value="<?php echo $exp_on; ?>" type="text" required>
            </div>
            <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
            <button type="submit" class="btn btn-success" style="background-color:#426047 !important;" name="updateCoupon">Update</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php
    }
?>